using UnityEngine;
using UnityEngine.Rendering;

namespace CyberWestJourney
{
    /// <summary>
    /// 将 3D 世界坐标的深度值实时转换为 SortingGroup 的 sortingOrder。
    /// 让 2D/Spine/粒子等插片在 3D 场景中始终按深度稳定渲染。
    /// </summary>
    [RequireComponent(typeof(SortingGroup))]
    public class DepthSort : MonoBehaviour
    {
        public enum SortAxis
        {
            ZAxis,   // 按 Z 排序：越接近相机越大
            YAxis    // 按 Y 排序：越靠下(数值小)越大，一般用于 45° 俯视
        }

        [Header("排序方式")]
        [Tooltip("按 Z 轴还是 Y 轴做深度转 Order")] 
        public SortAxis sortAxis = SortAxis.ZAxis;

        [Header("缩放系数")]
        [Tooltip("1 个世界单位转换成多少个 sortingOrder，按需调整，避免精度丢失")] 
        public float factor = 100f;

        [Header("统一偏移量")]
        [Tooltip("给 Order 叠加的全局偏移。如果想让特定角色整体在最前，可以在这里+值")] 
        public int orderOffset = 0;

        private SortingGroup _sg;
        private int _lastOrder;

        private void Awake()
        {
            _sg = GetComponent<SortingGroup>();
        }

        private void LateUpdate()
        {
            // 根据选择的轴把深度转成排序值
            float depth = sortAxis == SortAxis.ZAxis ? transform.position.z : -transform.position.y;
            int newOrder = -(int)(depth * factor) + orderOffset;

            // 只有变化时才刷新，避免每帧脏标记浪费性能
            if (newOrder != _lastOrder)
            {
                _sg.sortingOrder = newOrder;
                _lastOrder = newOrder;
            }
        }
    }
}