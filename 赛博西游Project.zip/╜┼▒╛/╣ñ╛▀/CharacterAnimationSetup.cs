using UnityEngine;
using 赛博西游Project.角色;

/// <summary>
/// 角色动画设置助手：用于检查和修复角色动画配置
/// </summary>
[AddComponentMenu("赛博西游/工具/角色动画设置助手")]
public class CharacterAnimationSetup : MonoBehaviour
{
    [Header("配置")]
    public 角色基类 目标角色;
    public 角色动画代理 目标动画代理;
    
    [Header("自动配置")]
    public bool 自动查找角色组件 = true;
    public bool 运行时自动修复 = true;
    public bool 仅首次运行时修复 = true;
    
    private static bool 已运行修复 = false;
    
    void Reset()
    {
        目标角色 = GetComponent<角色基类>();
        if (目标角色 != null)
        {
            目标动画代理 = 目标角色.动画代理;
        }
    }
    
    void OnValidate()
    {
        if (自动查找角色组件)
        {
            目标角色 = GetComponent<角色基类>() ?? GetComponentInParent<角色基类>();
            if (目标角色 != null && 目标动画代理 == null)
            {
                目标动画代理 = 目标角色.动画代理;
            }
        }
    }

    void Start()
    {
        if (!运行时自动修复) return;
        if (仅首次运行时修复 && 已运行修复) return;
        
        CheckAndFixAnimationSetup();
        已运行修复 = true;
    }
    
    /// <summary>
    /// 检查并修复动画设置
    /// </summary>
    public void CheckAndFixAnimationSetup()
    {
        // 查找角色和动画代理组件
        if (目标角色 == null)
        {
            目标角色 = GetComponent<角色基类>() ?? GetComponentInParent<角色基类>();
            if (目标角色 == null)
            {
                Debug.LogError($"[角色动画设置] {gameObject.name} 未找到角色基类组件！请确保此工具挂在角色节点上。");
                return;
            }
        }
        
        if (目标动画代理 == null)
        {
            目标动画代理 = 目标角色.动画代理;
            if (目标动画代理 == null)
            {
                Debug.LogWarning($"[角色动画设置] {目标角色.name} 未找到动画代理组件，尝试自动查找...");
                目标动画代理 = 目标角色.GetComponentInChildren<角色动画代理>();
                
                if (目标动画代理 == null)
                {
                    Debug.LogError($"[角色动画设置] {目标角色.name} 无法找到动画代理！请确保角色模型层级下有包含角色动画代理脚本的对象。");
                    return;
                }
                else
                {
                    // 自动连接
                    目标角色.动画代理 = 目标动画代理;
                    Debug.Log($"[角色动画设置] 已自动为角色 {目标角色.name} 连接动画代理组件！");
                }
            }
        }
        
        // 同步动画槽映射
        SyncAnimationSlots();
    }
    
    /// <summary>
    /// 同步动画槽映射
    /// </summary>
    private void SyncAnimationSlots()
    {
        if (目标动画代理 == null) return;
        
        bool hasChanges = false;
        
        // 检查必要的基础动画槽映射
        string[] 基础槽名 = new string[] { "待机", "移动", "跳跃", "攻击1", "攻击2" };
        string[] 基础动画名 = new string[] { "Idle", "Move", "Jump", "Attack1", "Attack2" };
        
        for (int i = 0; i < 基础槽名.Length; i++)
        {
            var 现有槽 = 目标动画代理.动画列表.Find(s => s.槽名 == 基础槽名[i]);
            if (现有槽 != null)
            {
                if (string.IsNullOrEmpty(现有槽.动画名))
                {
                    现有槽.动画名 = 基础动画名[i];
                    hasChanges = true;
                }
            }
            else
            {
                目标动画代理.动画列表.Add(new 角色动画代理.动画槽 { 槽名 = 基础槽名[i], 动画名 = 基础动画名[i] });
                hasChanges = true;
            }
        }
        
        if (hasChanges)
        {
            Debug.Log($"[角色动画设置] 已为角色 {目标角色.name} 更新动画槽映射！");
        }
    }
    
    /// <summary>
    /// 测试动画槽
    /// </summary>
    public void TestAnimation(string slotName)
    {
        if (目标动画代理 == null) return;
        
        bool 成功 = 目标动画代理.切换动画槽(slotName, true);
        Debug.Log($"[角色动画设置] 测试动画槽 {slotName}: {(成功 ? "成功" : "失败")}");
    }
    
    /// <summary>
    /// 测试所有基础动画
    /// </summary>
    public void TestAllAnimations()
    {
        string[] slots = new string[] { "待机", "移动", "跳跃", "攻击1", "攻击2" };
        foreach (string slot in slots)
        {
            TestAnimation(slot);
        }
    }
}