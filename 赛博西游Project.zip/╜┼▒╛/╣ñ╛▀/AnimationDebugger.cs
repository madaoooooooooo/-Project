using UnityEngine;
using 赛博西游Project.角色;
using System.Collections.Generic;

/// <summary>
/// 动画调试工具：用于检查和修复动画不触发的问题
/// </summary>
public class AnimationDebugger : MonoBehaviour
{
    public 角色基类 目标角色;
    public 角色动画代理 目标动画代理;
    
    [Header("动画槽调试")]
    public string 测试槽名 = "待机";
    public bool 循环播放 = true;
    
    [Header("动画槽映射配置")]
    public List<string> 待添加槽名 = new List<string>() { "待机", "移动", "跳跃", "攻击1", "攻击2" };
    public List<string> 待添加动画名 = new List<string>() { "Idle", "Move", "Jump", "Attack1", "Attack2" };
    
    [Header("调试信息")]
    [SerializeField] private string 当前动画名;
    [SerializeField] private bool 动画代理可用;
    [SerializeField] private bool Spine动画可用;
    
    void OnValidate()
    {
        if (目标角色 == null && 目标动画代理 == null)
        {
            目标角色 = FindObjectOfType<角色基类>();
            if (目标角色 != null)
            {
                目标动画代理 = 目标角色.动画代理;
            }
            else
            {
                目标动画代理 = FindObjectOfType<角色动画代理>();
            }
        }
        
        更新调试信息();
    }
    
    void Start()
    {
        更新调试信息();
    }
    
    public void 更新调试信息()
    {
        if (目标动画代理 != null)
        {
            动画代理可用 = true;
            
            if (目标动画代理.GetComponent<Spine.Unity.SkeletonAnimation>() != null)
            {
                Spine动画可用 = true;
                当前动画名 = 目标动画代理.GetComponent<Spine.Unity.SkeletonAnimation>().AnimationName;
            }
            else
            {
                Spine动画可用 = false;
                当前动画名 = "未找到Spine动画组件";
            }
        }
        else
        {
            动画代理可用 = false;
            当前动画名 = "未找到动画代理";
        }
    }
    
    public void 测试播放动画()
    {
        if (目标动画代理 != null)
        {
            bool 成功 = 目标动画代理.切换动画槽(测试槽名, 循环播放);
            Debug.Log($"测试播放动画槽 [{测试槽名}] " + (成功 ? "成功" : "失败"));
            if (!成功)
            {
                string anim = 目标动画代理.取动画名(测试槽名);
                Debug.LogWarning($"槽名 [{测试槽名}] 对应的动画名为: {(string.IsNullOrEmpty(anim) ? "未设置" : anim)}");
            }
            更新调试信息();
        }
    }
    
    public void 配置动画映射()
    {
        if (目标动画代理 != null)
        {
            int 添加计数 = 0;
            int 更新计数 = 0;
            
            // 确保待添加槽名和待添加动画名长度一致
            int 最小长度 = Mathf.Min(待添加槽名.Count, 待添加动画名.Count);
            
            for (int i = 0; i < 最小长度; i++)
            {
                string 槽名 = 待添加槽名[i];
                string 动画名 = 待添加动画名[i];
                
                var 现有槽 = 目标动画代理.动画列表.Find(s => s.槽名 == 槽名);
                if (现有槽 != null)
                {
                    if (现有槽.动画名 != 动画名)
                    {
                        现有槽.动画名 = 动画名;
                        更新计数++;
                    }
                }
                else
                {
                    目标动画代理.动画列表.Add(new 角色动画代理.动画槽 { 槽名 = 槽名, 动画名 = 动画名 });
                    添加计数++;
                }
            }
            
            Debug.Log($"动画槽映射配置完成: 添加 {添加计数} 项, 更新 {更新计数} 项");
        }
    }
    
    void OnGUI()
    {
        if (!Application.isPlaying) return;
        
        GUILayout.BeginArea(new Rect(10, 10, 300, 500));
        GUILayout.Label("==== 动画调试工具 ====");
        GUILayout.Label($"动画代理: {(动画代理可用 ? "可用" : "不可用")}");
        GUILayout.Label($"Spine动画: {(Spine动画可用 ? "可用" : "不可用")}");
        GUILayout.Label($"当前动画: {当前动画名}");
        
        GUILayout.Space(10);
        测试槽名 = GUILayout.TextField(测试槽名, GUILayout.Width(200));
        循环播放 = GUILayout.Toggle(循环播放, "循环播放");
        
        if (GUILayout.Button("测试播放动画"))
        {
            测试播放动画();
        }
        
        if (GUILayout.Button("配置默认动画映射"))
        {
            配置动画映射();
        }
        
        if (GUILayout.Button("更新调试信息"))
        {
            更新调试信息();
        }
        
        GUILayout.EndArea();
    }
}