using UnityEngine;
using Spine.Unity;
using System.Linq;
using System.Collections.Generic;

namespace 赛博西游Project.角色
{
    /// <summary>
    /// 角色基类，所有角色（玩家、敌人、NPC、Boss）通用属性和方法
    /// </summary>
    public class 角色基类 : MonoBehaviour
    {
        public string 角色ID;
        public string 角色名称;
        public int 阵营;
        public GameObject 角色模型;
        public Animator 角色动画;
        // 其他通用属性

        // 物理相关属性
        [Header("物理属性")]
        public Rigidbody 角色刚体;
        public Collider 角色碰撞体;

        [Header("Spine动画组件")]
        public SkeletonAnimation 角色Spine动画;
        
        // 动画名常量，便于统一管理
        public const string 动画名_Idle = "Idle";
        public const string 动画名_Move = "Move";
        public const string 动画名_Attack1 = "Attack1";
        public const string 动画名_Attack2 = "Attack2";
        public const string 动画名_BeAttacked = "BeAttacked";
        public const string 动画名_CastingIdle = "CastingIdle";
        public const string 动画名_Celebrate = "Celebrate";
        public const string 动画名_Deaded = "Deaded";
        public const string 动画名_Individuality = "Individuality";
        public const string 动画名_Skill = "Skill";

        private static readonly string[] _基础槽 = { "待机", "移动", "跳跃" };

        [Header("自定义动画槽(不含待机/移动/跳跃)")]
        public List<string> 动画槽列表 = new List<string>();

        // 当前动画名
        protected string 当前动画名 = null;

        public Transform 运动参考对象; // 用于检测移动的Transform
        private Vector3 上一帧位置;
        private float 当前速度 = 0f; // 用于动画切换的当前速度
        private Vector3 上一物理帧位置;

        public 角色动画代理 动画代理; // 动画代理引用

        // 动画切换缓冲相关字段
        private float 动画切换计时器 = 0f;
        private const float 动画切换延迟 = 0.15f; // 动画切换缓冲时间（秒）
        private const float 移动阈值 = 0.12f; // 进入移动动画的速度阈值
        private const float 静止阈值 = 0.05f; // 进入Idle动画的速度阈值

        [Header("视觉节点")]
        [Tooltip("仅用于左右翻转的节点(挂载SkeletonAnimation或MeshRenderers)，保持根节点缩放为正，避免碰撞体负尺寸")] 
        public Transform 可翻转节点;

        [Header("翻转设置")]
        [Tooltip("若模型默认面向左侧，请取消勾选，使向右移动时 scale.x 为负")] 
        public bool 右移为正Scale = true;

        private int 当前朝向 = 1; // 1为右，-1为左
        /// <summary>
        /// 当前角色面向方向：1=右，-1=左
        /// </summary>
        public int 朝向 => 当前朝向;

        // ===== Idle/Move 自动切换锁定 =====
        private float _idleMoveLockTimer = 0f; // >0 时禁止自动Idle/Move切换
        private const float 输入移动阈值 = 0.1f; // 输入向量判定移动阈值

        // 跳跃状态
        private bool _跳跃进行中 = false;
        private bool _已触发下落动画 = false; // 避免重复播放落地动画
        // 起跳后角色真正离地的标志，只有在检测到离地后，落地相关逻辑才允许生效
        private bool _已离地 = false;

        void Start()
        {
            // 获取组件引用（需在编辑器中手动挂载）
            角色刚体 = GetComponent<Rigidbody>();
            角色碰撞体 = GetComponent<Collider>();
            if (角色刚体 == null || 角色碰撞体 == null)
            {
                Debug.LogError($"[角色基类] {gameObject.name} 缺少Rigidbody或Collider，请在编辑器中手动添加！");
            }
            // 自动查找动画代理
            if (动画代理 == null)
            {
                动画代理 = GetComponentInChildren<角色动画代理>();
                if (动画代理 == null)
                {
                    Debug.LogWarning($"[角色基类] {gameObject.name} 未找到角色动画代理组件，动画切换将无效！");
                }
            }
            // 自动查找 SkeletonAnimation（支持子节点）
            if (角色Spine动画 == null)
            {
                角色Spine动画 = GetComponentInChildren<SkeletonAnimation>();
            }

            // 若未指定可翻转节点，则尝试自动查找SkeletonAnimation所在Transform
            if (可翻转节点 == null)
            {
                if (角色Spine动画 != null)
                    可翻转节点 = 角色Spine动画.transform;
                else if (角色模型 != null)
                    可翻转节点 = 角色模型.transform;
                else
                    可翻转节点 = transform; // 兜底
            }

            // 确保根节点缩放为正，避免BoxCollider负尺寸
            Vector3 rootScale = transform.localScale;
            rootScale.x = Mathf.Abs(rootScale.x);
            transform.localScale = rootScale;

            // 初始化角色朝向（利用当前可翻转节点缩放和设置开关）
            if (可翻转节点 != null)
            {
                float sign = Mathf.Sign(可翻转节点.localScale.x);
                if (右移为正Scale)
                    当前朝向 = sign >= 0 ? 1 : -1;
                else
                    当前朝向 = sign >= 0 ? -1 : 1;
            }

            // 初始化上一帧位置
            Transform refTrans = 运动参考对象 != null ? 运动参考对象 : transform;
            上一帧位置 = refTrans.position;
            上一物理帧位置 = refTrans.position; // 初始化物理帧位置

            // 同步动画槽
            同步动画槽到代理();
        }


        // 强制锁定插片旋转，防止被物理或其他系统影响
        void LateUpdate()
        {
            // 让插片正面始终朝向摄像机
            if (Camera.main != null)
            {
                transform.forward = Camera.main.transform.forward;
            }
        }

        void Awake()
        {
            // 自动检测并添加BoxCollider，保证所有角色都有基础碰撞体
            if (GetComponent<Collider>() == null)
            {
                gameObject.AddComponent<BoxCollider>();
                Debug.LogWarning($"[角色基类] {gameObject.name} 未检测到碰撞体，已自动添加BoxCollider。建议根据实际需求调整碰撞体类型和参数。");
            }
        }

        /// <summary>
        /// 通用Spine动画切换方法
        /// </summary>
        /// <param name="动画名">Spine动画名</param>
        /// <param name="循环">是否循环</param>
        public virtual void 切换动画(string 动画名, bool 循环 = true)
        {
            if (角色Spine动画 == null)
            {
                角色Spine动画 = GetComponent<SkeletonAnimation>();
                if (角色Spine动画 == null)
                {
                    Debug.LogWarning($"{gameObject.name} 未找到SkeletonAnimation组件，无法切换Spine动画！");
                    return;
                }
            }
            if (当前动画名 != 动画名)
            {
                if (角色Spine动画.Skeleton?.Data?.FindAnimation(动画名) == null)
                {
                    Debug.LogWarning($"[角色基类] Skeleton中未找到动画 {动画名}，跳过播放。");
                    return;
                }

                var entry = 角色Spine动画.AnimationState.SetAnimation(0, 动画名, 循环);
                if (!循环 && entry != null)
                {
                    // 为一次性动作在结束后自动回Idle
                    entry.Complete += (trackEntry) =>
                    {
                        切换到基础Idle或Move();
                    };
                }
                当前动画名 = 动画名;
            }
        }

        void FixedUpdate()
        {
            Transform refTrans = 运动参考对象 != null ? 运动参考对象 : transform;
            当前速度 = ((refTrans.position - 上一物理帧位置) / Time.fixedDeltaTime).magnitude;
            上一物理帧位置 = refTrans.position;

            // 跳跃过程下落检测：下降阶段并且距离地面<=阈值时触发落地动画
            if (_跳跃进行中 && _已离地 && !_已触发下落动画 && 动画代理 != null)
            {
                if (角色刚体 != null && 角色刚体.velocity.y < -0.01f)
                {
                    float distToGround = 999f;
                    // 使用移动能力的地面层进行射线检测
                    var moveAbility = GetComponent<移动能力>();
                    LayerMask groundMask = moveAbility != null ? moveAbility.跳跃参数.地面层 : Physics.DefaultRaycastLayers;

                    Vector3 origin = transform.position + Vector3.up * 0.1f; // 稍微往上，避免Collider内部
                    if (Physics.Raycast(origin, Vector3.down, out RaycastHit hitInfo, 5f, groundMask))
                    {
                        distToGround = hitInfo.distance;
                    }

                    if (distToGround <= 动画代理.落地提前距离)
                    {
                        _已触发下落动画 = true;
                        动画代理.播放落地(false);

                        if (角色Spine动画 != null)
                        {
                            var entryTmp = 角色Spine动画.AnimationState.GetCurrent(0);
                            if (entryTmp != null)
                            {
                                entryTmp.Complete += (e) => 切换到基础Idle或Move();
                            }
                        }
                    }
                }
            }

            // 检测落地切换落地动画
            if (_跳跃进行中)
            {
                var moveAb = GetComponent<移动能力>();
                if (moveAb != null)
                {
                    // 检测离地（仅一次）
                    if (!_已离地 && !moveAb.IsGrounded)
                    {
                        _已离地 = true;
                    }

                    // 只有在已离地之后再次接触地面才算真正落地
                    if (_已离地 && moveAb.IsGrounded)
                    {
                        _跳跃进行中 = false;
                        if (!_已触发下落动画)
                        {
                            动画代理?.播放落地(false);
                            // 动画完再回Idle/Move
                            var entry = 角色Spine动画.AnimationState.GetCurrent(0);
                            if (entry != null)
                            {
                                entry.Complete += (e) => 切换到基础Idle或Move();
                            }
                        }
                        else
                        {
                            // 若已播放落地动画，则等待动画结束后回Idle/Move（已在下落阶段注册回调）
                        }
                    }
                }
            }
        }

        protected virtual void Update()
        {
            // 更新锁定计时器
            if (_idleMoveLockTimer > 0f)
            {
                _idleMoveLockTimer -= Time.deltaTime;
            }

            // 不再在Update中采样和计算速度，直接用当前速度
            // if (Time.frameCount % 10 == 0)
            // {
            //     Debug.Log($"当前速度: {当前速度}");
            // }

            // ----- Idle / Move 自动切换（输入优先 + 可锁定） -----
            if (动画代理 != null && _idleMoveLockTimer <= 0f)
            {
                bool 主动移动 = false;
                var moveAbility = GetComponent<移动能力>();
                if (moveAbility != null && moveAbility.输入向量.magnitude > 输入移动阈值)
                {
                    主动移动 = true;
                }

                if (主动移动 && 当前动画名 != 动画名_Move)
                {
                    动画切换计时器 += Time.deltaTime;
                    if (动画切换计时器 > 动画切换延迟)
                    {
                        动画代理.切换动画槽("移动", true);
                        当前动画名 = 动画名_Move;
                        动画切换计时器 = 0f;
                    }
                }
                else if (!主动移动)
                {
                    // 根据速度阈值二次判定
                    if (当前速度 > 移动阈值 && 当前动画名 != 动画名_Move)
                    {
                        动画切换计时器 += Time.deltaTime;
                        if (动画切换计时器 > 动画切换延迟)
                        {
                            动画代理.切换动画槽("移动", true);
                            当前动画名 = 动画名_Move;
                            动画切换计时器 = 0f;
                        }
                    }
                    else if (当前速度 < 静止阈值 && 当前动画名 != 动画名_Idle)
                    {
                        动画切换计时器 += Time.deltaTime;
                        if (动画切换计时器 > 动画切换延迟)
                        {
                            动画代理.切换动画槽("待机", true);
                            当前动画名 = 动画名_Idle;
                            动画切换计时器 = 0f;
                        }
                    }
                    else
                    {
                        // 无需切换
                        动画切换计时器 = 0f;
                    }
                }
                else
                {
                    // 保持当前状态
                    动画切换计时器 = 0f;
                }
            }

            // 行业内通用做法：Movement动画时根据输入向量x分量进行水平翻转
            if (当前动画名 == 动画名_Move)
            {
                var 移动能力 = GetComponent<移动能力>();
                if (移动能力 != null)
                {
                    float 横向 = 移动能力.输入向量.x;
                    if (横向 > 0.01f && 当前朝向 != 1)
                    {
                        if (可翻转节点 != null)
                        {
                            Vector3 s = 可翻转节点.localScale;
                            s.x = 右移为正Scale ? Mathf.Abs(s.x) : -Mathf.Abs(s.x);
                            可翻转节点.localScale = s;
                        }
                        当前朝向 = 1;
                    }
                    else if (横向 < -0.01f && 当前朝向 != -1)
                    {
                        if (可翻转节点 != null)
                        {
                            Vector3 s = 可翻转节点.localScale;
                            s.x = 右移为正Scale ? -Mathf.Abs(s.x) : Mathf.Abs(s.x);
                            可翻转节点.localScale = s;
                        }
                        当前朝向 = -1;
                    }
                }
            }

            //==================== 新增：特殊待机动画检测 ====================
            // 若动画代理存在，则在每帧检测是否需要切换到多段待机动画
            if (动画代理 != null)
            {
                bool 处于基础待机 = 当前动画名 == 动画名_Idle;
                动画代理.检查并切换特殊待机动画(处于基础待机, Time.deltaTime);
            }
            //================================================================
        }

        /// <summary>
        /// 编辑器属性变动时自动同步动画槽到动画代理
        /// </summary>
        private void OnValidate()
        {
            同步动画槽到代理();
        }

        /// <summary>
        /// 将<see cref="动画槽列表"/>内容与动画代理保持一致
        /// </summary>
        private void 同步动画槽到代理()
        {
            if (动画代理 == null) return;

            // 1. 移除所有基础槽，确保列表仅用于自定义槽显示
            动画代理.动画列表.RemoveAll(s => _基础槽.Contains(s.槽名));

            // 2. 添加自定义槽（忽略与基础槽同名的情况）
            foreach (string name in 动画槽列表)
            {
                if (!动画代理.动画列表.Exists(s => s.槽名 == name))
                {
                    动画代理.动画列表.Add(new 角色动画代理.动画槽 { 槽名 = name });
                }
            }

            // 3. 移除已在 Inspector 中删除的自定义槽
            动画代理.动画列表.RemoveAll(s => !动画槽列表.Contains(s.槽名));
        }

        /// <summary>
        /// 在外部播放高优先级动画时调用，用于暂时禁止自动Idle/Move切换
        /// </summary>
        /// <param name="持续时间">锁定时长（秒）</param>
        public void 锁定IdleMove切换(float 持续时间)
        {
            // 取最大，避免被较短锁定覆盖
            if (持续时间 > _idleMoveLockTimer)
                _idleMoveLockTimer = 持续时间;

            if (持续时间 > 0.01f && Application.isPlaying)
            {
                // Debug日志已注释，防止刷屏
                // Debug.Log($"[角色基类] 锁定IdleMove {持续时间:F3}s (Timer={_idleMoveLockTimer:F3})");
            }
        }

        /// <summary>
        /// 根据当前输入/速度立即切换到 Idle 或 Move，用于一次性动作结束后的回退。
        /// </summary>
        private void 切换到基础Idle或Move()
        {
            var moveAbility = GetComponent<移动能力>();

            bool 主动移动 = moveAbility != null && moveAbility.输入向量.magnitude > 输入移动阈值;

            if (主动移动 || 当前速度 > 移动阈值)
            {
                动画代理?.切换动画槽("移动", true);
                当前动画名 = 动画名_Move;
            }
            else
            {
                动画代理?.切换动画槽("待机", true);
                当前动画名 = 动画名_Idle;
            }

            动画切换计时器 = 0f; // 立即回归，不再等待缓冲
            _idleMoveLockTimer = 0f; // 解除锁定，允许正常逻辑继续
        }

        /// <summary>
        /// 外部触发跳跃三段动画（在移动能力请求跳跃后调用）。
        /// </summary>
        public void 触发跳跃动画()
        {
            if (动画代理 == null || 角色Spine动画 == null) return;

            _跳跃进行中 = true;
            _已触发下落动画 = false;
            _已离地 = false; // 重置离地标志，等待后续检测
            // 锁定，以免Idle/Move覆盖
            锁定IdleMove切换(5f);

            // ------------------- 新实现 -------------------
            // 直接使用 Spine 的队列系统，确保"起跳 → 滞空"顺序播放
            string 起跳名 = 动画代理?.跳跃动画.起跳;
            string 滞空名 = 动画代理?.跳跃动画.滞空;

            var state = 角色Spine动画.AnimationState;

            if (!string.IsNullOrEmpty(起跳名))
            {
                // 起跳为一次性动画
                state.SetAnimation(0, 起跳名, false);

                // 起跳播放完毕后，无缝衔接滞空循环动画
                if (!string.IsNullOrEmpty(滞空名))
                {
                    state.AddAnimation(0, 滞空名, true, 0f);
                }
                当前动画名 = 起跳名;
            }
            else if (!string.IsNullOrEmpty(滞空名))
            {
                // 如果未配置起跳动画，直接播放滞空循环
                state.SetAnimation(0, 滞空名, true);
                当前动画名 = 滞空名;
            }
        }

        /// <summary>
        /// 供外部(如动画代理)在一次性动作播放完毕后调用，立即根据当前状态回退到Idle或Move。
        /// </summary>
        public void 回到基础Idle或Move()
        {
            切换到基础Idle或Move();
        }

        /// <summary>
        /// 立即面向世界坐标点（仅修改可翻转节点的scale.x）。
        /// </summary>
        /// <param name="worldPos">目标世界坐标</param>
        public void 面向坐标(Vector3 worldPos)
        {
            if (可翻转节点 == null) return;

            float dir = worldPos.x - transform.position.x;
            if (Mathf.Abs(dir) < 0.01f) return; // 距离过近不翻转

            if (dir > 0f && 当前朝向 != -1)
            {
                Vector3 s = 可翻转节点.localScale;
                s.x = 右移为正Scale ? -Mathf.Abs(s.x) : Mathf.Abs(s.x);
                可翻转节点.localScale = s;
                当前朝向 = -1;
            }
            else if (dir < 0f && 当前朝向 != 1)
            {
                Vector3 s = 可翻转节点.localScale;
                s.x = 右移为正Scale ? Mathf.Abs(s.x) : -Mathf.Abs(s.x);
                可翻转节点.localScale = s;
                当前朝向 = 1;
            }
        }
    }
} 