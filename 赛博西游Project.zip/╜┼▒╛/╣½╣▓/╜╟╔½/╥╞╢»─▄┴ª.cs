using UnityEngine;
using System.Collections;

/// <summary>
/// 通用移动能力组件，只负责输入与位移，不涉及物理碰撞与跳跃
/// </summary>
public class 移动能力 : MonoBehaviour
{
    [Header("移动参数")]
    [Tooltip("移动速度")]
    [HideInInspector]
    public float 移动速度 = 5f;

    [Header("尺寸补偿")]
    [Tooltip("视觉尺寸缩放系数，模型放大3倍则填3，会按比例放大速度/力度。")]
    public float 尺寸缩放系数 = 1f;

    #region 可折叠参数组定义
    [System.Serializable]
    public class 跳跃参数组
    {
        public float 跳跃力度 = 5f;
        public int 最大连跳次数 = 2;
        public float 跳跃缓冲时间 = 0.1f;
        public float 土狼时间 = 0.1f;
        public float 地面检测距离 = 0.2f;
        public LayerMask 地面层;
        public float 头顶检测距离 = 0.2f;
        public LayerMask 障碍层;
        [Tooltip("地面射线Y偏移(正值向上)")]
        public float 地面射线Y偏移 = 0f;
    }

    [System.Serializable]
    public class 跳跃手感组
    {
        public float 跳跃最大持续时间 = 0.2f;
        public float 上升重力系数 = 1f;
        public float 下落重力系数 = 2.5f;
        public float 地面检测额外偏移 = 0f;
    }

    [System.Serializable]
    public class 冲击翻滚组
    {
        public float 冲击翻滚速度 = 12f;
        public float 空中冲击持续时间 = 0.2f;
        public float 翻滚持续时间 = 0.25f;
        public float 冲击翻滚间隔 = 0.5f;
    }

    //[Header("跳跃参数")]
    [HideInInspector]
    public 跳跃参数组 跳跃参数 = new 跳跃参数组();

    //[Header("跳跃手感优化")]
    [HideInInspector]
    public 跳跃手感组 跳跃手感优化 = new 跳跃手感组();

    //[Header("冲击/翻滚参数")]
    [HideInInspector]
    public 冲击翻滚组 冲击翻滚参数 = new 冲击翻滚组();
    #endregion

    // [已弃用] 原有内部输入检测逻辑已被解耦，保留占位方便旧预制兼容。
    [System.Obsolete("内部输入检测已移除，请通过外部脚本驱动移动能力。", false)]
    public bool 使用内部输入检测 = false;

    // 提供给外部脚本的输入接口
    #region 外部输入接口
    /// <summary>
    /// 外部设置移动输入向量
    /// </summary>
    public void 设置输入向量(Vector3 向量)
    {
        _输入向量 = new Vector3(向量.x, 0, 向量.z).normalized;
        if (向量.x > 0.01f)
            _最后按下水平 = 1;
        else if (向量.x < -0.01f)
            _最后按下水平 = -1;
    }

    /// <summary>
    /// 外部触发一次跳跃请求
    /// </summary>
    public void 请求跳跃()
    {
        _上次跳跃请求时间 = Time.time;
    }

    /// <summary>
    /// 外部设置跳跃键是否长按状态，用于变高度跳跃
    /// </summary>
    public void 设置持续跳跃(bool 长按)
    {
        _正在跳跃 = 长按;
    }

    /// <summary>
    /// 外部触发一次冲击/翻滚请求
    /// </summary>
    public void 请求冲击()
    {
        if (Time.time - _上次冲击时间 >= 冲击翻滚间隔)
            _冲击请求 = true;
    }
    #endregion

    public Vector3 输入向量 { get { return _输入向量; } }
    private Vector3 _输入向量;
    private float _地面检测上次打印时间 = 0f;
    private float _头顶检测上次打印时间 = 0f;
    private float _检测打印间隔 = 0.5f;

    private Vector3 _地面检测命中点 = Vector3.zero;
    private bool _地面检测上次命中 = false;

    // 记录最后一次按下的水平方向，1 表示 D（右），-1 表示 A（左），0 表示无
    private int _最后按下水平 = 0;

    // 冲击控制变量
    private bool _冲击请求 = false;
    private bool _正在冲击 = false;
    private float _冲击开始时间 = 0f;
    private float _冲击持续时长 = 0f;
    private Vector3 _冲击方向 = Vector3.zero;
    private float _上次冲击时间 = -999f;

    // 由玩家控制器同步，Inspector 不显示
    [HideInInspector]
    public float 地面射线Y偏移 = 0f;

    // 以下旧字段隐藏，仅供代码使用，数值由 OnValidate 同步
    [HideInInspector] public float 跳跃力度 = 5f;
    [HideInInspector] public int 最大连跳次数 = 2;
    [HideInInspector] public float 跳跃缓冲时间 = 0.1f;
    [HideInInspector] public float 土狼时间 = 0.1f;
    [HideInInspector] public float 地面检测距离 = 0.2f;
    [HideInInspector] public LayerMask 地面层;
    [HideInInspector] public float 头顶检测距离 = 0.2f;
    [HideInInspector] public LayerMask 障碍层;

    [HideInInspector] public float 跳跃最大持续时间 = 0.2f;
    [HideInInspector] public float 上升重力系数 = 1f;
    [HideInInspector] public float 下落重力系数 = 2.5f;
    [HideInInspector] public float 地面检测额外偏移 = 0f;

    [HideInInspector] public float 冲击翻滚速度 = 12f;
    [HideInInspector] public float 冲击持续时间 = 0.2f;
    [HideInInspector] public float 翻滚持续时间 = 0.25f;
    [HideInInspector] public float 冲击翻滚间隔 = 0.5f;

    private Rigidbody _rigidbody;
    // BoxCollider缓存，用于精确地面检测
    private BoxCollider _boxCollider;

    // 跳跃相关
    private float _上次跳跃请求时间 = -999f;
    private float _最后在地面时间 = -999f;
    private int _跳跃计数 = 0;
    private bool _上帧在地面 = false;

    private bool _正在跳跃 = false;
    private float _跳跃开始时间 = 0f;

    public bool IsGrounded { get; private set; }

    void Awake()
    {
        _rigidbody = GetComponent<Rigidbody>();
        _boxCollider = GetComponent<BoxCollider>();
        if (_boxCollider == null)
        {
            // Debug.LogWarning("[移动能力] 未找到BoxCollider，地面检测将使用默认偏移");
        }

        // 确保运行时参数同步
        SyncParameters();
    }

    // 在 Inspector 调整参数时同步到内部字段，保证运行时逻辑使用最新值
    void OnValidate()
    {
        SyncParameters();
    }

    // 双向同步：若折叠组值与隐藏字段有差异，以折叠组为准；否则保持原有隐藏字段
    void SyncParameters()
    {
        // 跳跃参数
        跳跃力度 = 跳跃参数.跳跃力度;
        最大连跳次数 = 跳跃参数.最大连跳次数;
        跳跃缓冲时间 = 跳跃参数.跳跃缓冲时间;
        土狼时间 = 跳跃参数.土狼时间;
        地面检测距离 = 跳跃参数.地面检测距离;
        地面层 = 跳跃参数.地面层;
        头顶检测距离 = 跳跃参数.头顶检测距离;
        障碍层 = 跳跃参数.障碍层;

        // 射线偏移
        地面射线Y偏移 = 跳跃参数.地面射线Y偏移;

        // 跳跃手感
        跳跃最大持续时间 = 跳跃手感优化.跳跃最大持续时间;
        上升重力系数 = 跳跃手感优化.上升重力系数;
        下落重力系数 = 跳跃手感优化.下落重力系数;
        地面检测额外偏移 = 跳跃手感优化.地面检测额外偏移;

        // 冲击/翻滚
        冲击翻滚速度 = 冲击翻滚参数.冲击翻滚速度;
        冲击持续时间 = 冲击翻滚参数.空中冲击持续时间;
        翻滚持续时间 = 冲击翻滚参数.翻滚持续时间;
        冲击翻滚间隔 = 冲击翻滚参数.冲击翻滚间隔;

        // 尺寸补偿：按系数放大速度/力度相关值
        if (!Mathf.Approximately(尺寸缩放系数, 1f))
        {
            移动速度 *= 尺寸缩放系数;
            跳跃力度 *= 尺寸缩放系数;
            冲击翻滚速度 *= 尺寸缩放系数;
        }
    }

    // 内部输入已被外部系统替代，此处保留空实现避免旧引用报错。
    void Update() { }

    void FixedUpdate()
    {
        bool 在地面 = 检测地面();
        IsGrounded = 在地面;
        if (在地面)
        {
            if (!_上帧在地面)
            {
                _跳跃计数 = 0;
                // Debug.Log("[跳跃调试] 检测到落地，跳跃计数重置");
            }
            _最后在地面时间 = Time.time;
        }
        else
        {
            if (_上帧在地面)
            {
                // Debug.Log("[跳跃调试] 离开地面");
            }
        }
        _上帧在地面 = 在地面;

        // 跳跃缓冲+土狼时间+连跳
        bool 可跳 = false;
        if (Time.time - _上次跳跃请求时间 < 跳跃缓冲时间)
        {
            if (在地面 || (Time.time - _最后在地面时间 < 土狼时间) || (_跳跃计数 < 最大连跳次数 && 最大连跳次数 > 1))
            {
                if (_跳跃计数 < 最大连跳次数)
                {
                    可跳 = true;
                }
            }
        }
        if (可跳)
        {
            跳跃();
            _跳跃计数++;
            _上次跳跃请求时间 = -999f;
            // Debug.Log($"[跳跃调试] 执行跳跃，当前跳跃计数: {_跳跃计数}");
        }
        else if (Time.time - _上次跳跃请求时间 < 跳跃缓冲时间)
        {
            // Debug.Log($"[跳跃调试] 跳跃条件不满足，地面: {在地面}，土狼: {Time.time - _最后在地面时间 < 土狼时间}，跳跃计数: {_跳跃计数}");
        }

        // 处理冲击 / 翻滚 请求
        if (_冲击请求)
        {
            _正在冲击 = true;
            _冲击开始时间 = Time.time;
            _冲击持续时长 = 在地面 ? 翻滚持续时间 : 冲击持续时间;

            // 计算冲击方向：
            Vector3 dir = Vector3.zero;
            if (_输入向量.magnitude > 0.1f)
            {
                dir = new Vector3(_输入向量.x, 0, _输入向量.z).normalized;
            }

            // 若未输入方向，则使用面向左右（_最后按下水平）。默认面向右
            if (dir == Vector3.zero)
            {
                int face = _最后按下水平 == 0 ? 1 : _最后按下水平; // 0 -> 默认右
                dir = new Vector3(face, 0, 0);
            }

            // 将方向限定为水平或45度斜向
            if (Mathf.Abs(dir.x) < 0.01f) // 纯纵向，不允许
            {
                // 强制斜向：根据面向决定水平分量
                int face = dir.z >= 0 ? (_最后按下水平 == 0 ? 1 : _最后按下水平) : (_最后按下水平 == 0 ? 1 : _最后按下水平);
                dir = new Vector3(face, 0, Mathf.Sign(dir.z));
            }
            else if (Mathf.Abs(dir.z) > 0.01f)
            {
                // 斜向，归一到45°
                dir = new Vector3(Mathf.Sign(dir.x), 0, Mathf.Sign(dir.z)).normalized;
            }
            else
            {
                // 纯水平无需处理
            }

            _冲击方向 = dir;

            // 关闭重力
            _rigidbody.useGravity = false;

            // TODO: 若在地面可播放翻滚动画

            _冲击请求 = false;
            _上次冲击时间 = Time.time;
        }

        // 冲击移动（空中）
        if (_正在冲击)
        {
            if (Time.time - _冲击开始时间 < _冲击持续时长)
            {
                Vector3 dashMove = _冲击方向 * 冲击翻滚速度 * Time.fixedDeltaTime;
                _rigidbody.MovePosition(_rigidbody.position + dashMove);
            }
            else
            {
                _正在冲击 = false;
                _rigidbody.useGravity = true; // 恢复重力
            }
        }

        // 普通移动（未在冲击状态时始终允许）
        if (!_正在冲击 && _输入向量.magnitude > 0.01f)
        {
            Vector3 move = _输入向量 * 移动速度 * Time.fixedDeltaTime;
            _rigidbody.MovePosition(_rigidbody.position + new Vector3(move.x, 0, move.z));
        }

        // 跳跃重力曲线与变高度跳跃
        if (!_上帧在地面 && !_正在冲击)
        {
            Vector3 v = _rigidbody.velocity;
            if (v.y > 0)
            {
                // 上升阶段
                if (_正在跳跃 && (Time.time - _跳跃开始时间 < 跳跃最大持续时间))
                {
                    // 维持正常重力
                    _rigidbody.AddForce(Physics.gravity * (上升重力系数 - 1), ForceMode.Acceleration);
                }
                else
                {
                    // 松开跳跃键或超时，快速下落
                    _正在跳跃 = false;
                    _rigidbody.AddForce(Physics.gravity * (下落重力系数 - 1), ForceMode.Acceleration);
                }
            }
            else if (v.y < 0)
            {
                // 下落阶段加速
                _rigidbody.AddForce(Physics.gravity * (下落重力系数 - 1), ForceMode.Acceleration);
            }
        }

        // 头顶碰撞检测，防止浮空
        if (检测头顶())
        {
            Vector3 v = _rigidbody.velocity;
            if (v.y > 0)
            {
                _rigidbody.velocity = new Vector3(v.x, 0, v.z);
                // Debug.Log("[跳跃调试] 检测到头顶碰撞，y速度清零");
            }
        }
    }

    void 跳跃()
    {
        _rigidbody.velocity = new Vector3(_rigidbody.velocity.x, 0, _rigidbody.velocity.z); // 保证每次跳跃初速度一致
        _rigidbody.AddForce(Vector3.up * 跳跃力度, ForceMode.Impulse);
        _正在跳跃 = true;
        _跳跃开始时间 = Time.time;
    }

    bool 检测地面()
    {
        Vector3 origin;
        float 检测距离 = 地面检测距离 > 0.5f ? 地面检测距离 : 0.5f;
        // 优先使用BoxCollider底部中心作为射线起点
        if (_boxCollider != null)
        {
            // 计算BoxCollider底部中心的世界坐标
            Vector3 centerWorld = transform.TransformPoint(_boxCollider.center);
            float halfHeight = _boxCollider.size.y * 0.5f * Mathf.Abs(transform.lossyScale.y);
            origin = centerWorld + Vector3.down * halfHeight;
            origin += Vector3.down * 地面检测额外偏移; // 垂直微调
            origin += Vector3.up * 地面射线Y偏移; // 仅Y方向调节
        }
        else
        {
            // 兼容原有逻辑
            origin = transform.position + Vector3.down * 0.5f + Vector3.down * 地面检测额外偏移 + Vector3.up * 地面射线Y偏移;
        }
        RaycastHit hit;
        bool 命中 = Physics.Raycast(origin, Vector3.down, out hit, 检测距离, 地面层);
        Debug.DrawRay(origin, Vector3.down * 检测距离, 命中 ? Color.green : Color.red, 0.1f);
        if (Time.time - _地面检测上次打印时间 > _检测打印间隔)
        {
            // Debug.Log($"[地面检测] 起点: {origin}, 方向: {Vector3.down}, 距离: {检测距离}, 命中: {命中}");
            // if (命中)
            //     Debug.Log("[跳跃调试] 检测到地面命中");
            _地面检测上次打印时间 = Time.time;
        }
        if (命中)
        {
            _地面检测命中点 = hit.point;
            _地面检测上次命中 = true;
        }
        else
        {
            _地面检测命中点 = origin + Vector3.down * 检测距离;
            _地面检测上次命中 = false;
        }
        return 命中;
    }

    bool 检测头顶()
    {
        Vector3 origin = transform.position + Vector3.up * 0.5f;
        float 检测距离 = 头顶检测距离 > 0.5f ? 头顶检测距离 : 0.5f;
        bool 命中 = Physics.Raycast(origin, Vector3.up, 检测距离, 障碍层);
        Debug.DrawRay(origin, Vector3.up * 检测距离, 命中 ? Color.green : Color.red, 0.1f);
        if (Time.time - _头顶检测上次打印时间 > _检测打印间隔)
        {
            // Debug.Log($"[头顶检测] 起点: {origin}, 方向: {Vector3.up}, 距离: {检测距离}, 命中: {命中}");
            // if (命中)
            //     Debug.Log("[跳跃调试] 检测到头顶命中");
            _头顶检测上次打印时间 = Time.time;
        }
        return 命中;
    }

    void OnDrawGizmos()
    {
        // 可视化地面检测射线和命中点
        Vector3 origin = transform.position + Vector3.down * 0.5f + Vector3.down * 地面检测额外偏移 + Vector3.up * 地面射线Y偏移;
        float 检测距离 = 地面检测距离 > 0.5f ? 地面检测距离 : 0.5f;
        Gizmos.color = Color.yellow;
        Gizmos.DrawLine(origin, origin + Vector3.down * 检测距离);
        if (_地面检测上次命中)
        {
            Gizmos.color = Color.green;
            Gizmos.DrawSphere(_地面检测命中点, 0.15f);
        }
        else
        {
            Gizmos.color = Color.red;
            Gizmos.DrawSphere(origin + Vector3.down * 检测距离, 0.15f);
        }
    }

    // 供外部同步数据的API（方案A）
    public void ApplyExternalParameters(float moveSpeed, 跳跃参数组 j, 跳跃手感组 h, 冲击翻滚组 c)
    {
        移动速度 = moveSpeed;
        跳跃参数 = j;
        跳跃手感优化 = h;
        冲击翻滚参数 = c;
        SyncParameters();
    }
} 