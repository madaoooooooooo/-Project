using UnityEngine;
using Unity.Cinemachine;

/// <summary>
/// Cinemachine 扩展：实现左右移动阈值与跳跃抬升限制
/// 将此脚本挂到虚拟机位（跟随摄像机）上，无需改动或禁用现有 Cinemachine 组件。
/// 仅暴露两个可调参数：左右阈值、跳跃抬升最大值。
/// </summary>
[AddComponentMenu("Cinemachine/Extensions/简易跟随限制(左右阈值·跳跃抬升)")]
// 让脚本在 Cinemachine 完成 Body 运算后执行，确保最终姿态被覆盖
[DefaultExecutionOrder(100)]
public class 镜头控制 : CinemachineExtension
{
    [Tooltip("左右移动阈值")] public float 左右阈值 = 2f;
    [Tooltip("跳跃Y轴抬升最大值")] public float 跳跃抬升最大值 = 1f;
    [Tooltip("跳跃抬升回落缓冲速度(单位/秒)")] public float 缓冲速度 = 5f;

    private bool _初始化完成;
    private float _基础高度;
    private float _初始目标Y;
    private Vector3 _目标偏移; // 摄像机与主角的初始偏移
    private float _跟随中心X;
    private float _当前抬升;

    protected override void PostPipelineStageCallback(
        CinemachineVirtualCameraBase vcam,
        CinemachineCore.Stage stage,
        ref CameraState state,
        float deltaTime)
    {
        // 只在 Body 阶段修改最终位置
        if (stage != CinemachineCore.Stage.Body) return;

        Transform 目标 = vcam.Follow;
        if (目标 == null) return;

        // 首帧初始化：记录基础高度、初始目标Y、初始偏移、跟随中心
        if (!_初始化完成)
        {
            _基础高度 = state.RawPosition.y;
            _初始目标Y = 目标.position.y;
            _目标偏移 = state.RawPosition - 目标.position; // 含XZ偏移
            _跟随中心X = 目标.position.x;
            _当前抬升 = 0f;
            _初始化完成 = true;
        }

        // 计算左右阈值：只有当目标离开阈值范围才移动中心
        float dx = 目标.position.x - _跟随中心X;
        if (Mathf.Abs(dx) > 左右阈值)
        {
            // 把中心推到阈值边缘，避免一次性移动过大
            _跟随中心X = 目标.position.x - 左右阈值 * Mathf.Sign(dx);
        }

        Vector3 desiredPos = _目标偏移; // 保持原始偏移
        desiredPos.x += _跟随中心X;
        desiredPos.z += 目标.position.z; // Z 仍然全程跟随，可按需要改

        // 跳跃抬升：仅在主角高于初始高度时抬升，并限制最大值
        float jumpDelta = Mathf.Max(0f, 目标.position.y - _初始目标Y);
        float targetYOffset = Mathf.Min(jumpDelta, 跳跃抬升最大值);
        // 使用 MoveTowards 实现缓冲：上升立即跟随，下降逐渐回落
        _当前抬升 = Mathf.MoveTowards(_当前抬升, targetYOffset, Time.deltaTime * 缓冲速度);
        desiredPos.y = _基础高度 + _当前抬升;

        state.RawPosition = desiredPos;
    }
} 