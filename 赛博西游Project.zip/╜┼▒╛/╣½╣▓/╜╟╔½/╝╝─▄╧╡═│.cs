using UnityEngine;
using System.Collections.Generic;

namespace 赛博西游Project.角色
{
    /// <summary>
    /// 技能系统：保存并执行角色的攻击/技能逻辑。
    /// 用于玩家或 AI 角色。
    /// </summary>
    [AddComponentMenu("赛博西游/角色/技能系统")]
    public class 技能系统 : MonoBehaviour
    {
        [System.Serializable]
        public class 技能数据
        {
            public string 技能名 = "LightAttack";      // 唯一标识
            public int 伤害 = 10;                      // 造成的伤害
            public float 冷却 = 0.3f;                  // 冷却时长
            public string 动画槽 = "Attack1";         // 对应动画槽
            public float 施放距离 = 1.2f;             // 判定距离 (近战)
        }

        [Header("技能列表")]
        public List<技能数据> 技能列表 = new List<技能数据>();

        // ===== 运行时字段 =====
        private readonly Dictionary<string, float> _上次施放时间 = new Dictionary<string, float>();
        private 角色基类 _角色基类;

        void Awake()
        {
            _角色基类 = GetComponent<角色基类>();
        }

        /// <summary>
        /// 尝试施放技能，对目标造成伤害。(近战示例)
        /// </summary>
        /// <param name="技能名">技能标识</param>
        /// <param name="目标">受击角色</param>
        public bool 尝试施放(string 技能名, 角色基类 目标)
        {
            var data = 技能列表.Find(s => s.技能名 == 技能名);
            if (data == null) return false; // 未配置

            // 冷却检测
            if (_上次施放时间.TryGetValue(技能名, out float t) && Time.time - t < data.冷却)
                return false;

            // 角色面向目标
            if (目标 != null) 面向目标(目标.transform);

            // 本脚本不再切换动画，由玩家控制器负责播放一次性动作动画，避免Track被覆盖

            // 若存在可复用的攻击能力组件，使用盒体检测造成伤害
            var attackAbility = GetComponent<攻击能力>();
            if (attackAbility != null)
            {
                attackAbility.伤害 = data.伤害; // 同步本次技能伤害
                attackAbility.尝试攻击();
            }
            else
            {
                // 近战距离判定并应用伤害（旧实现）
                if (目标 != null && Vector3.Distance(transform.position, 目标.transform.position) <= data.施放距离)
                {
                    var hp = 目标.GetComponent<生命属性>();
                    hp?.受击(data.伤害);
                }
            }

            _上次施放时间[技能名] = Time.time;
            return true;
        }

        /// <summary>
        /// 将角色朝向目标 (仅左右翻转，不旋转根节点)。
        /// </summary>
        private void 面向目标(Transform target)
        {
            if (target == null || _角色基类 == null) return;
            float dir = target.position.x - transform.position.x;
            if (Mathf.Abs(dir) < 0.01f) return;

            int sign = dir > 0 ? 1 : -1;
            if (_角色基类.朝向 == sign) return; // 已面向

            var flipNode = _角色基类.可翻转节点;
            if (flipNode != null)
            {
                Vector3 s = flipNode.localScale;
                s.x = _角色基类.右移为正Scale ? Mathf.Abs(s.x) * sign : -Mathf.Abs(s.x) * sign;
                flipNode.localScale = s;
            }
        }
    }
} 