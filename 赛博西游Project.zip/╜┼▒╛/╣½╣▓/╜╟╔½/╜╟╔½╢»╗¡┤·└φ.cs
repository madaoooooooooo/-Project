using UnityEngine;
using Spine.Unity;
using System.Collections.Generic;

/// <summary>
/// 角色动画代理，专门用于Spine动画对象，供主角等逻辑对象调用动画切换
/// </summary>
public class 角色动画代理 : MonoBehaviour
{
    /// <summary>
    /// 动画槽：左侧业务标签，右侧具体Spine动画名
    /// </summary>
    [System.Serializable]
    public class 动画槽
    {
        public string 槽名 = "NewSlot"; // 业务名，如 Jump / Attack1
        public string 动画名;            // Spine中的真正动画名
    }

    // 基础槽绑定（待机、移动、跳跃三段）
    [System.Serializable]
    public class 跳跃组合
    {
        [Tooltip("起跳动画 Clip 名称")]
        public string 起跳;
        [Tooltip("滞空循环动画 Clip 名称")]
        public string 滞空;
        [Tooltip("落地动画 Clip 名称")]
        public string 落地;
    }

    [System.Serializable]
    public class 特殊待机动画
    {
        [Tooltip("Spine动画名")] public string 动画名;
        [Tooltip("静止多少秒后可触发")] public float 触发时间 = 2f;
        [Tooltip("出现权重/概率")] public float 权重 = 1f;
        [Tooltip("播放时长(秒)。>0 时循环播放该时长后自动回Idle；<=0 时按一次性动画处理")] public float 播放时长 = 3f;
    }

    [Header("动画槽绑定 (由角色基类同步，勿手动增删)")]
    // 注意：动画槽的增删请在角色基类Inspector中操作，此处只负责动画名绑定
    public System.Collections.Generic.List<动画槽> 动画列表 = new System.Collections.Generic.List<动画槽>();

    [Header("调试")]
    public bool 调试模式 = false;

    [Header("基础槽绑定 (必填)")]
    public string 待机动画;   // 若为空则通过槽"待机"获取
    public string 移动动画;
    public 跳跃组合 跳跃动画 = new 跳跃组合();

    [Header("落地检测")]
    [Tooltip("提前触发落地动画的距离(米)。当角色下降并与地面距离小于等于该值时播放落地动画")]
    public float 落地提前距离 = 0.3f;

    [Header("多段待机动画配置")]
    public List<特殊待机动画> 多段待机动画列表 = new List<特殊待机动画>();

    private SkeletonAnimation 角色Spine动画;

    // 内部状态
    private float 待机计时 = 0f;
    private bool 正在特殊待机 = false;
    private 特殊待机动画 当前特殊待机 = null;
    private float 特殊待机剩余时长 = 0f; // 当前特殊待机循环剩余时间
    private bool _特殊待机已禁用 = false; // 死亡后禁用

    void Awake()
    {
        角色Spine动画 = GetComponent<SkeletonAnimation>();
        if (角色Spine动画 == null)
        {
            // Debug.LogWarning($"{gameObject.name} 未找到SkeletonAnimation组件，无法切换Spine动画！");
        }
    }

    /// <summary>
    /// 切换Spine动画
    /// </summary>
    /// <param name="动画名">Spine动画名</param>
    /// <param name="循环">是否循环</param>
    public void 切换动画(string 动画名, bool 循环 = true)
    {
        // Debug.Log($"[动画代理] 切换到动画: {动画名}, 循环: {循环}");

        // 若正在特殊待机，但即将播放的动画不是当前特殊待机动画，则立即退出特殊待机状态
        if (正在特殊待机 && 当前特殊待机 != null && 动画名 != 当前特殊待机.动画名)
        {
            立即退出特殊待机();
        }

        if (角色Spine动画 != null && 角色Spine动画.AnimationName != 动画名)
        {
            var entry = 角色Spine动画.AnimationState.SetAnimation(0, 动画名, 循环);

            // 若为一次性动画，在完成后自动回Idle/Move
            if (!循环 && entry != null)
            {
                var baseComp = GetComponentInParent<赛博西游Project.角色.角色基类>();
                if (baseComp != null)
                {
                    entry.Complete += (e) =>
                    {
                        // 调试日志移除，避免刷屏
                        baseComp.回到基础Idle或Move();
                    };
                }
            }
        }
    }

    /// <summary>
    /// 通过槽名切换动画，若未匹配返回false
    /// </summary>
    public bool 切换动画槽(string 槽名, bool 循环 = true)
    {
        string anim = 取动画名(槽名);
        if (!string.IsNullOrEmpty(anim))
        {
            if (调试模式)
                Debug.Log($"[动画代理] 切换槽 {槽名} -> 动画 {anim}");
            切换动画(anim, 循环);
            return true;
        }
        Debug.LogWarning($"[动画代理] 未找到槽名 {槽名} 对应的动画，请在动画列表中配置！");
        return false;
    }

    /// <summary>
    /// 根据槽名获取绑定的Spine动画名
    /// </summary>
    public string 取动画名(string 槽名)
    {
        // 基础槽直接使用专用绑定字段，避免依赖动画列表
        switch (槽名)
        {
            case "待机":
                return 待机动画;
            case "移动":
                return 移动动画;
            default:
                var slot = 动画列表.Find(s => s.槽名 == 槽名);
                return slot != null ? slot.动画名 : null;
        }
    }

    #region 跳跃播放辅助
    public void 播放起跳(bool 循环 = false)
    {
        if (!string.IsNullOrEmpty(跳跃动画.起跳))
            切换动画(跳跃动画.起跳, 循环);
    }
    public void 播放滞空()
    {
        if (!string.IsNullOrEmpty(跳跃动画.滞空))
            切换动画(跳跃动画.滞空, true);
    }
    public void 播放落地(bool 循环 = false)
    {
        if (!string.IsNullOrEmpty(跳跃动画.落地))
            切换动画(跳跃动画.落地, 循环);
    }
    #endregion

    /// <summary>
    /// 在Update中调用，传入是否处于基础待机状态
    /// </summary>
    public void 检查并切换特殊待机动画(bool 处于基础待机, float deltaTime)
    {
        if (_特殊待机已禁用) return; // 已被禁用

        // 若正在播放特殊待机动画，则更新计时并在到时后回Idle
        if (正在特殊待机)
        {
            if (当前特殊待机 != null && 当前特殊待机.播放时长 > 0f)
            {
                特殊待机剩余时长 -= deltaTime;
                if (特殊待机剩余时长 <= 0f)
                {
                    // 回到基础待机
                    切换动画槽("待机", true);
                    正在特殊待机 = false;
                    当前特殊待机 = null;
                    待机计时 = 0f;
                }
            }
            return; // 特殊待机播放中
        }

        if (!处于基础待机 || 多段待机动画列表.Count == 0)
        {
            待机计时 = 0f;
            return;
        }

        待机计时 += deltaTime;
        // 找出所有可触发的特殊待机动画
        var 可触发 = 多段待机动画列表.FindAll(a => 待机计时 >= a.触发时间);
        if (可触发.Count > 0)
        {
            // 按权重随机选择一个
            float total = 0f;
            foreach (var a in 可触发) total += Mathf.Max(0.01f, a.权重);
            float r = Random.Range(0, total);
            float acc = 0f;
            foreach (var a in 可触发)
            {
                acc += Mathf.Max(0.01f, a.权重);
                if (r <= acc)
                {
                    // 若设置播放时长>0，则循环播放该时长；否则按一次性动画播放
                    bool 循环 = a.播放时长 > 0f;
                    切换动画(a.动画名, 循环);

                    正在特殊待机 = true;
                    当前特殊待机 = a;

                    特殊待机剩余时长 = a.播放时长;

                    if (!循环 && 角色Spine动画 != null)
                    {
                        var entryNow = 角色Spine动画.AnimationState.GetCurrent(0);
                        if (entryNow != null)
                        {
                            entryNow.Complete += (e) =>
                            {
                                // 完成后回Idle已由Complete事件处理，这里额外重置状态机
                                正在特殊待机 = false;
                                当前特殊待机 = null;
                                待机计时 = 0f;
                            };
                        }
                    }
                    待机计时 = 0f;
                    break;
                }
            }
        }
    }

    /// <summary>
    /// 立即退出特殊待机状态并重置计时。
    /// </summary>
    public void 立即退出特殊待机(bool 重置计时 = true)
    {
        if (正在特殊待机)
        {
            正在特殊待机 = false;
            当前特殊待机 = null;
        }
        if (重置计时)
        {
            待机计时 = 0f;
        }
    }

    /// <summary>
    /// 外部调用：永久禁用特殊待机动画（如角色死亡）。
    /// </summary>
    public void 禁用特殊待机()
    {
        _特殊待机已禁用 = true;
        立即退出特殊待机(false);
    }
} 