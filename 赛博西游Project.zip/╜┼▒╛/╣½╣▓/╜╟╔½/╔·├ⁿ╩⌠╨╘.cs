using UnityEngine;
using System;

namespace 赛博西游Project.角色
{
    /// <summary>
    /// 生命属性组件：处理生命值、受击与死亡。
    /// 独立于移动/输入逻辑，保持单一职责。
    /// </summary>
    [AddComponentMenu("赛博西游/角色/生命属性组件")]
    public class 生命属性 : MonoBehaviour
    {
        [Header("生命设置")]
        [Tooltip("最大生命值")]
        public int 最大生命 = 100;
        [Tooltip("初始/当前生命值")]
        public int 当前生命 = 100;

        [Header("受击无敌帧")]
        [Tooltip("每次受击后进入的短暂无敌时长(秒)")]
        public float 受击无敌时长 = 0.2f;

        // ===== 运行时字段 =====
        private float _最后受击时间 = -999f;
        private 角色基类 _角色基类;
        private bool _已死亡 = false;

        // ===== 事件 =====
        public event Action<int, int> On生命变化;      // 当前生命, 最大生命
        public event Action<int> On受击;              // 伤害值
        public event Action On死亡;

        void Awake()
        {
            _角色基类 = GetComponent<角色基类>();
            当前生命 = Mathf.Clamp(当前生命, 0, 最大生命);
        }

        /// <summary>
        /// 承受伤害(受击)。
        /// </summary>
        /// <param name="伤害值">正值表示扣血</param>
        public void 受击(int 伤害值)
        {
            if (_已死亡) return; // 已死亡不再触发

            // 无敌帧判定
            if (Time.time - _最后受击时间 < 受击无敌时长) return;
            _最后受击时间 = Time.time;

            if (伤害值 <= 0) return;

            当前生命 = Mathf.Max(0, 当前生命 - 伤害值);
            Debug.Log($"[受击] {gameObject.name} 受到 {伤害值} 伤害，剩余 {当前生命}/{最大生命}");
            On受击?.Invoke(伤害值);
            On生命变化?.Invoke(当前生命, 最大生命);

            // 若有动画代理，先退出特殊待机状态
            bool 播放成功 = false;
            if (_角色基类 != null && _角色基类.动画代理 != null)
            {
                _角色基类.动画代理.立即退出特殊待机();
                播放成功 = _角色基类.动画代理.切换动画槽("受击", false);
            }

            if (!播放成功)
            {
                // 回退到直接使用常量动画名
                _角色基类?.切换动画(角色基类.动画名_BeAttacked, false);
            }

            if (当前生命 == 0 && !_已死亡)
            {
                On死亡?.Invoke();
                _已死亡 = true;

                // 播放死亡动画一次并保持最后一帧
                string 死亡动画名 = 角色基类.动画名_Deaded;
                if (_角色基类 != null && _角色基类.动画代理 != null)
                {
                    死亡动画名 = _角色基类.动画代理.取动画名("死亡") ?? 角色基类.动画名_Deaded;
                    _角色基类.动画代理.禁用特殊待机();
                }

                if (_角色基类 != null && _角色基类.角色Spine动画 != null)
                {
                    var sa = _角色基类.角色Spine动画;
                    if (sa.Skeleton?.Data?.FindAnimation(死亡动画名) != null)
                    {
                        sa.AnimationState.SetAnimation(0, 死亡动画名, false);
                    }
                }
            }
        }

        /// <summary>
        /// 带攻击者信息的受击接口，能根据攻击来源翻转朝向。
        /// </summary>
        public void 受击(int 伤害值, Transform 攻击者)
        {
            if (_已死亡) return;
            if (攻击者 != null && _角色基类 != null)
            {
                _角色基类.面向坐标(攻击者.position);
            }

            受击(伤害值); // 调用原有逻辑
        }

        /// <summary>
        /// 回复生命。
        /// </summary>
        public void 回复(int 数值)
        {
            if (数值 <= 0) return;
            当前生命 = Mathf.Min(最大生命, 当前生命 + 数值);
            On生命变化?.Invoke(当前生命, 最大生命);
        }
    }
} 