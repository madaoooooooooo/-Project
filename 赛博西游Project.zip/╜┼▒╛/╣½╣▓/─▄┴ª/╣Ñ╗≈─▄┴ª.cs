using UnityEngine;
using System.Collections.Generic;

namespace 赛博西游Project.角色
{
    /// <summary>
    /// 近战盒体攻击能力：在角色前方生成一个可配置的OverlapBox，
    /// 对命中的其他角色施加伤害。可被玩家、Boss、敌人共用。
    /// </summary>
    [AddComponentMenu("赛博西游/能力/攻击能力")]
    public class 攻击能力 : MonoBehaviour
    {
        [Header("攻击设置")]
        [Tooltip("造成的基础伤害，若技能系统在调用时会覆盖此值")] 
        public int 伤害 = 10;

        [Tooltip("两次攻击的最小间隔(秒)")] 
        public float 冷却 = 0.3f;

        [Tooltip("盒体中心(本地坐标)")] 
        public Vector3 盒体中心 = new Vector3(1f, 1f, 0f);

        [Tooltip("盒体尺寸")] 
        public Vector3 盒体尺寸 = new Vector3(1.6f, 2f, 1f);

        [Tooltip("检测的目标层，在Project->Tags&Layers里配置")] 
        public LayerMask 目标层 = ~0; // 默认全部

        [Tooltip("盒体的参考点，不设置则默认取transform")] 
        public Transform 参考点;

        // 冷却计时
        private float _lastAttackTime = -999f;

        /// <summary>
        /// 执行一次近战盒体判定并对命中目标造成伤害。
        /// </summary>
        /// <returns>是否成功执行(通过冷却检测)</returns>
        public bool 尝试攻击()
        {
            Debug.Log("尝试攻击被调用");
            if (Time.time - _lastAttackTime < 冷却)
                return false; // 冷却中

            Debug.Log($"[攻击能力] {gameObject.name} 执行攻击判定");

            _lastAttackTime = Time.time;

            // 修正：支持父物体scale.x为负时，自动镜像盒体中心
            float scaleX = transform.lossyScale.x;
            Vector3 boxCenter = 盒体中心;
            Vector3 boxSize = 盒体尺寸;
            if (scaleX < 0)
            {
                boxCenter.x = -boxCenter.x; // 镜像中心
                // boxSize.x 不需要取反，尺寸始终为正
            }
            Vector3 origin = (参考点 != null ? 参考点.position : transform.position) + transform.TransformDirection(boxCenter);
            Collider[] hits = Physics.OverlapBox(origin, boxSize * 0.5f, transform.rotation, 目标层);

            // 新增：打印判定盒体参数和命中对象，避免刷屏
            string hitNames = hits.Length > 0 ? string.Join(", ", System.Array.ConvertAll(hits, h => h.gameObject.name)) : "无";
            Debug.Log($"[攻击能力-调试] OverlapBox原点:{origin} 尺寸:{boxSize} 旋转:{transform.rotation.eulerAngles} 命中:{hitNames}");

            if (hits.Length == 0)
            {
                Debug.Log("[攻击能力] 未命中任何目标");
                return true;
            }

            角色基类 selfRole = GetComponent<角色基类>();

            foreach (var col in hits)
            {
                // 排除自身碰撞
                if (col.attachedRigidbody != null && col.attachedRigidbody.gameObject == gameObject)
                    continue;

                角色基类 otherRole = col.GetComponentInParent<角色基类>();
                if (otherRole == null || otherRole == selfRole)
                    continue;

                // 简单阵营判定：不同阵营才受击
                if (selfRole != null && otherRole.阵营 == selfRole.阵营)
                    continue;

                var hp = otherRole.GetComponent<生命属性>();
                if (hp != null)
                {
                    Debug.Log($"[攻击能力] 命中 {otherRole.gameObject.name} 造成 {伤害} 伤害");
                    hp.受击(伤害, transform);
                }
            }
            return true;
        }

        // ===== 调试可视化 =====
        private void OnDrawGizmosSelected()
        {
            Gizmos.color = new Color(1f, 0f, 0f, 0.4f);
            Vector3 origin = (参考点 != null ? 参考点.position : transform.position) + transform.TransformDirection(盒体中心);
            Matrix4x4 prev = Gizmos.matrix;
            Gizmos.matrix = Matrix4x4.TRS(origin, transform.rotation, 盒体尺寸);
            Gizmos.DrawCube(Vector3.zero, Vector3.one);
            Gizmos.matrix = prev;
        }
    }
} 