using UnityEngine;
using UnityEditor;

#if UNITY_EDITOR
/// <summary>
/// 只保留动作名文本输入+KeyCode标准下拉菜单，保证序列化绝对正确。
/// </summary>
[CustomPropertyDrawer(typeof(赛博西游.管理器.输入管理器.自定义按键绑定))]
public class 自定义按键绑定Drawer : PropertyDrawer
{
    // 录入状态缓存
    private static string _recordingPath = null;

    public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
    {
        return EditorGUIUtility.singleLineHeight;
    }

    public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
    {
        SerializedProperty actionProp = property.FindPropertyRelative("动作名");
        SerializedProperty keyProp = property.FindPropertyRelative("键");

        float totalW = position.width;
        float col1 = totalW * 0.4f;
        float col2 = totalW * 0.4f;
        float col3 = totalW - col1 - col2;

        Rect r1 = new Rect(position.x, position.y, col1 - 2, position.height);
        Rect r2 = new Rect(r1.xMax + 2, position.y, col2 - 2, position.height);
        Rect r3 = new Rect(r2.xMax + 2, position.y, col3 - 2, position.height);

        EditorGUI.PropertyField(r1, actionProp, GUIContent.none);

        // KeyCode下拉
        KeyCode selected = (KeyCode)EditorGUI.EnumPopup(r2, (KeyCode)keyProp.intValue);
        keyProp.intValue = (int)selected;

        // 录入按钮
        string path = property.propertyPath;
        bool isRecording = _recordingPath == path;
        if (GUI.Button(r3, isRecording ? "按键..." : "录入"))
        {
            if (isRecording) _recordingPath = null;
            else _recordingPath = path;
        }
        // 捕获键盘事件
        if (isRecording && Event.current.type == EventType.KeyDown)
        {
            KeyCode kc = Event.current.keyCode;
            keyProp.intValue = (int)kc;
            _recordingPath = null;
            property.serializedObject.ApplyModifiedProperties();
            Event.current.Use();
        }
    }
}
#endif 