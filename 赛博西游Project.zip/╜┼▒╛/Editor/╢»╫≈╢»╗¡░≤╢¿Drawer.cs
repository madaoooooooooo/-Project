using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.Linq;
using 赛博西游.角色;
using 赛博西游.管理器;
using 赛博西游Project.角色;

#if UNITY_EDITOR
/// <summary>
/// 自定义 Inspector 绘制：玩家控制器.动作动画绑定
/// 自动列出 动作名(来自输入管理器) 与 动画槽(来自角色基类) 供下拉选择。
/// </summary>
[CustomPropertyDrawer(typeof(玩家控制器.动作动画绑定))]
public class 动作动画绑定Drawer : PropertyDrawer
{
    public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
    {
        return EditorGUIUtility.singleLineHeight;
    }

    public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
    {
        // 获取字段引用
        var actionProp = property.FindPropertyRelative("动作名");
        var slotProp = property.FindPropertyRelative("动画槽");
        var loopProp = property.FindPropertyRelative("循环");

        // 寻找上下文组件
        玩家控制器 pc = property.serializedObject.targetObject as 玩家控制器;
        角色基类 baseRole = pc != null ? pc.GetComponent<角色基类>() : null;
        输入管理器 im = 输入管理器.Instance ?? Object.FindObjectOfType<输入管理器>();

        // 构造动作名选项
        List<string> actionList = new List<string>();
        if (im != null)
        {
            actionList.AddRange(im.自定义按键.Select(k => k.动作名));
        }
        if (!actionList.Contains(actionProp.stringValue))
            actionList.Add(actionProp.stringValue);
        actionList.Insert(0, "<None>");

        // 构造动画槽选项
        List<string> slotList = new List<string>();
        if (baseRole != null)
        {
            slotList.AddRange(baseRole.动画槽列表);
        }
        if (!slotList.Contains(slotProp.stringValue))
            slotList.Add(slotProp.stringValue);
        slotList.Insert(0, "<None>");

        // 列宽分配
        float w = position.width;
        float col1 = w * 0.38f;
        float col2 = w * 0.38f;
        float col3 = w - col1 - col2 - 4;

        Rect r1 = new Rect(position.x, position.y, col1, position.height);
        Rect r2 = new Rect(r1.xMax + 2, position.y, col2, position.height);
        Rect r3 = new Rect(r2.xMax + 2, position.y, col3, position.height);

        // 动作名只读显示
        EditorGUI.LabelField(r1, actionProp.stringValue);

        // 动画槽下拉
        int slotIdx = Mathf.Max(0, slotList.IndexOf(slotProp.stringValue));
        int newSlotIdx = EditorGUI.Popup(r2, slotIdx, slotList.ToArray());
        slotProp.stringValue = newSlotIdx == 0 ? string.Empty : slotList[newSlotIdx];

        // 循环复选框
        loopProp.boolValue = EditorGUI.Toggle(r3, loopProp.boolValue);
    }
}

[CustomEditor(typeof(赛博西游.角色.玩家控制器))]
public class 玩家控制器Editor : Editor
{
    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();
        if (GUILayout.Button("获取动作槽（同步输入管理器）"))
        {
            var pc = (赛博西游.角色.玩家控制器)target;
            var method = pc.GetType().GetMethod("SyncBindingsFromInputManager", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            if (method != null) method.Invoke(pc, null);
            var so = new SerializedObject(pc);
            so.ApplyModifiedProperties();
            EditorUtility.SetDirty(pc);
            Debug.Log("已同步玩家控制器动作动画绑定");
        }
    }
}
#endif 