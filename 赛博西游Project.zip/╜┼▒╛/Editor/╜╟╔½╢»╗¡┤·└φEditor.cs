using UnityEngine;
using UnityEditor;
using Spine.Unity;

#if UNITY_EDITOR
[CustomEditor(typeof(角色动画代理))]
public class 角色动画代理Editor : Editor
{
    private string[] _animNames = new string[0];
    private SerializedProperty _listProp;
    private SerializedProperty _idleProp;
    private SerializedProperty _moveProp;
    private SerializedProperty _jumpProp;
    private SerializedProperty _landingDistProp;
    private SerializedProperty _specialIdleListProp;

    void OnEnable()
    {
        var proxy = (角色动画代理)target;
        var sa = proxy.GetComponent<SkeletonAnimation>();
        if (sa != null && sa.Skeleton != null)
        {
            var anims = sa.Skeleton.Data.Animations;
            _animNames = new string[anims.Count + 1];
            _animNames[0] = "<None>"; // 首项为空表示解绑
            for (int i = 0; i < anims.Count; i++)
                _animNames[i + 1] = anims.Items[i].Name;
        }
        _listProp = serializedObject.FindProperty("动画列表");
        _idleProp = serializedObject.FindProperty("待机动画");
        _moveProp = serializedObject.FindProperty("移动动画");
        _jumpProp = serializedObject.FindProperty("跳跃动画");
        _landingDistProp = serializedObject.FindProperty("落地提前距离");
        _specialIdleListProp = serializedObject.FindProperty("多段待机动画列表");
    }

    public override void OnInspectorGUI()
    {
        serializedObject.Update();

        EditorGUILayout.LabelField("基础槽绑定", EditorStyles.boldLabel);

        DrawClipPopup("待机", _idleProp);
        DrawClipPopup("移动", _moveProp);

        // 跳跃三段
        EditorGUILayout.LabelField("跳跃", EditorStyles.boldLabel);
        var 起跳Prop = _jumpProp.FindPropertyRelative("起跳");
        var 滞空Prop = _jumpProp.FindPropertyRelative("滞空");
        var 落地Prop = _jumpProp.FindPropertyRelative("落地");
        DrawClipPopup("起跳", 起跳Prop);
        DrawClipPopup("滞空", 滞空Prop);
        DrawClipPopup("落地", 落地Prop);

        // 落地检测参数
        EditorGUILayout.Space();
        EditorGUILayout.LabelField("落地检测", EditorStyles.boldLabel);
        EditorGUILayout.PropertyField(_landingDistProp, new GUIContent("落地提前距离 (米)"));

        EditorGUILayout.Space();

        // ===== 多段待机动画配置 =====
        EditorGUILayout.LabelField("多段待机动画配置", EditorStyles.boldLabel);
        EditorGUILayout.HelpBox("可在此添加多个特殊待机动画，设置触发时间与出现权重。权重越高，被选中概率越大。", MessageType.Info);

        // 列表头
        EditorGUILayout.BeginHorizontal();
        GUILayout.Label("动画", GUILayout.MaxWidth(120));
        GUILayout.Label("触发时间(s)", GUILayout.MaxWidth(80));
        GUILayout.Label("持续(s)", GUILayout.MaxWidth(60));
        GUILayout.Label("权重", GUILayout.MaxWidth(60));
        GUILayout.FlexibleSpace();
        EditorGUILayout.EndHorizontal();

        for (int i = 0; i < _specialIdleListProp.arraySize; i++)
        {
            var elem = _specialIdleListProp.GetArrayElementAtIndex(i);
            var animNameProp = elem.FindPropertyRelative("动画名");
            var triggerTimeProp = elem.FindPropertyRelative("触发时间");
            var durationProp = elem.FindPropertyRelative("播放时长");
            var weightProp = elem.FindPropertyRelative("权重");

            EditorGUILayout.BeginHorizontal();

            // 动画下拉
            int animIdx = System.Array.IndexOf(_animNames, string.IsNullOrEmpty(animNameProp.stringValue) ? "<None>" : animNameProp.stringValue);
            if (animIdx < 0) animIdx = 0;
            int newAnimIdx = EditorGUILayout.Popup(animIdx, _animNames, GUILayout.MaxWidth(120));
            if (newAnimIdx == 0)
                animNameProp.stringValue = string.Empty;
            else if (_animNames.Length > newAnimIdx)
                animNameProp.stringValue = _animNames[newAnimIdx];

            // 触发时间、持续时长、权重
            triggerTimeProp.floatValue = EditorGUILayout.FloatField(triggerTimeProp.floatValue, GUILayout.MaxWidth(80));
            durationProp.floatValue = EditorGUILayout.FloatField(durationProp.floatValue, GUILayout.MaxWidth(60));
            weightProp.floatValue = EditorGUILayout.FloatField(weightProp.floatValue, GUILayout.MaxWidth(60));

            // 删除按钮
            if (GUILayout.Button("-", GUILayout.MaxWidth(20)))
            {
                _specialIdleListProp.DeleteArrayElementAtIndex(i);
                break; // 退出循环防止并发修改
            }

            EditorGUILayout.EndHorizontal();
        }

        // 添加按钮
        EditorGUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        if (GUILayout.Button("+ 添加特殊待机动画", GUILayout.MaxWidth(160)))
        {
            _specialIdleListProp.arraySize++;
            var newElem = _specialIdleListProp.GetArrayElementAtIndex(_specialIdleListProp.arraySize - 1);
            newElem.FindPropertyRelative("动画名").stringValue = string.Empty;
            newElem.FindPropertyRelative("触发时间").floatValue = 2f;
            newElem.FindPropertyRelative("播放时长").floatValue = 3f;
            newElem.FindPropertyRelative("权重").floatValue = 1f;
        }
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.Space();
        // ===== 结束 多段待机动画配置 =====

        EditorGUILayout.LabelField("自定义槽绑定 (由角色基类同步)", EditorStyles.boldLabel);
        EditorGUILayout.HelpBox("动画槽的增删请在角色基类Inspector的动画槽列表中操作。此处仅用于为每个槽名选择Spine动画名。", MessageType.Info);
        GUI.enabled = false;
        EditorGUILayout.PropertyField(_listProp, new GUIContent("动画槽列表 (只读)"), true);
        GUI.enabled = true;

        // 只允许为已有槽名选择动画名
        for (int i = 0; i < _listProp.arraySize; i++)
        {
            var elem = _listProp.GetArrayElementAtIndex(i);
            var slotNameProp = elem.FindPropertyRelative("槽名");
            var animNameProp = elem.FindPropertyRelative("动画名");

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(slotNameProp.stringValue, GUILayout.MaxWidth(80));
            int index = System.Array.IndexOf(_animNames, string.IsNullOrEmpty(animNameProp.stringValue) ? "<None>" : animNameProp.stringValue);
            if (index < 0) index = 0;
            int newIndex = EditorGUILayout.Popup(index, _animNames);
            if (newIndex == 0)
                animNameProp.stringValue = string.Empty; // 解绑
            else if (_animNames.Length > newIndex)
                animNameProp.stringValue = _animNames[newIndex];
            EditorGUILayout.EndHorizontal();
        }

        // 在Inspector底部添加同步按钮
        EditorGUILayout.Space();
        if (GUILayout.Button("从角色基类同步动画槽"))
        {
            Undo.RecordObject(target, "同步动画槽");
            var proxy = (角色动画代理)target;
            var charBase = proxy.GetComponentInParent<赛博西游Project.角色.角色基类>();
            if (charBase != null)
            {
                var slotNames = charBase.动画槽列表;

                // 1. 添加缺失槽
                foreach (var name in slotNames)
                {
                    if (!proxy.动画列表.Exists(s => s.槽名 == name))
                    {
                        proxy.动画列表.Add(new 角色动画代理.动画槽 { 槽名 = name });
                    }
                }
                // 2. 移除已删除槽
                proxy.动画列表.RemoveAll(s => !slotNames.Contains(s.槽名));

                // 3. 若Skeleton中存在同名动画且未绑定，尝试自动绑定
                var sa = proxy.GetComponent<SkeletonAnimation>();
                if (sa != null && sa.Skeleton != null)
                {
                    var anims = sa.Skeleton.Data.Animations;
                    foreach (var slot in proxy.动画列表)
                    {
                        if (string.IsNullOrEmpty(slot.动画名))
                        {
                            for (int i = 0; i < anims.Count; i++)
                            {
                                if (anims.Items[i].Name == slot.槽名)
                                {
                                    slot.动画名 = anims.Items[i].Name;
                                    break;
                                }
                            }
                        }
                    }
                }

                EditorUtility.SetDirty(proxy);
                serializedObject.Update();
            }
            else
            {
                Debug.LogWarning("[角色动画代理Editor] 未找到父级角色基类组件，无法同步动画槽。");
            }
        }

        serializedObject.ApplyModifiedProperties();
    }

    void DrawClipPopup(string label, SerializedProperty prop)
    {
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField(label, GUILayout.MaxWidth(60));
        int index = System.Array.IndexOf(_animNames, string.IsNullOrEmpty(prop.stringValue) ? "<None>" : prop.stringValue);
        if (index < 0) index = 0;
        int newIdx = EditorGUILayout.Popup(index, _animNames);
        if (newIdx == 0)
            prop.stringValue = string.Empty;
        else if (_animNames.Length > newIdx)
            prop.stringValue = _animNames[newIdx];
        EditorGUILayout.EndHorizontal();
    }
}
#endif 