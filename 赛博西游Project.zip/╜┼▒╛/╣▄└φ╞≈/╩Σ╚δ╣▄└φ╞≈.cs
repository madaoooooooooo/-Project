using UnityEngine;
using System.Collections.Generic;
using System.Linq;
// 让输入管理器在绝大多数脚本之前初始化，避免找不到实例

namespace 赛博西游.管理器
{
    /// <summary>
    /// 输入管理器，负责全局输入检测与分发。
    /// </summary>
    [AddComponentMenu("赛博西游/管理器/输入管理器")]
    [DefaultExecutionOrder(-200)]
    public class 输入管理器 : MonoBehaviour
    {
        // 单例便于全局访问
        public static 输入管理器 Instance { get; private set; }

        [Header("输入设置")]
        [Tooltip("是否启用输入检测")]
        public bool 输入检测激活 = true;
        [Tooltip("失去焦点时是否重置按钮状态")]
        public bool 失去焦点重置按钮 = true;

        [Header("玩家绑定")]
        [Tooltip("玩家ID，用于绑定输入与角色")]
        public string 玩家ID = "玩家1";

        [Header("按键映射")]
        public KeyCode 跳跃键 = KeyCode.Space;

        // 冲击/翻滚改为自定义动作，由动作名与自定义按键列表决定
        [Header("方向键(回退)")]
        public KeyCode 左键 = KeyCode.A;
        public KeyCode 右键 = KeyCode.D;
        public KeyCode 上键 = KeyCode.W;
        public KeyCode 下键 = KeyCode.S;

        [Header("移动设置")]
        [Tooltip("是否平滑移动（惯性）")]
        public bool 平滑移动 = true;
        [Tooltip("模拟摇杆触发移动的最小阈值")]
        public Vector2 移动阈值 = new Vector2(0.1f, 0.4f);

        [Header("调试")]
        public bool 调试模式 = false;

        // ========= 优先级设置 =========
        [Header("按键优先级")]
        [Tooltip("当组合按键被触发时，是否屏蔽其包含的单键动作（防止J+J被单独J抢占）")]
        public bool 组合触发屏蔽单键 = true;

        // ===== 自定义按键 =====
        [System.Serializable]
        public class 自定义按键绑定
        {
            public string 动作名 = "Attack1";      // 动作标识，与玩家控制器映射使用
            public KeyCode 键 = KeyCode.J;           // 按键，必须用UnityEngine.KeyCode
        }

        [Header("自定义按键列表")]
        public List<自定义按键绑定> 自定义按键 = new List<自定义按键绑定>();

        // ===== 组合按键 =====
        [System.Serializable]
        public class 组合按键绑定
        {
            [Tooltip("动作标识，与玩家控制器映射使用")]
            public string 动作名 = "DoubleJ";
            [Tooltip("按键序列，按触发顺序填写；若是双击J则填两次J；若是A+K则填A,K")] 
            public List<KeyCode> 键序列 = new List<KeyCode> { KeyCode.J, KeyCode.J };
            [Tooltip("从第一键到最后一键的最大允许间隔（秒）")]
            public float 最大触发间隔 = 0.3f;
            [Tooltip("触发后再次允许触发的冷却(秒)，0 表示等于最大触发间隔")] public float 冷却时长 = 0.0f;
            [Tooltip("是否忽略顺序，只要按下序列中所有按键即可触发（适合A+K这种同时键)")]
            public bool 忽略顺序 = false;
        }

        [Header("组合按键列表")]
        public List<组合按键绑定> 组合按键 = new List<组合按键绑定>();

        // 内部状态缓存
        private Vector3 _移动向量;
        private bool _跳跃按下;
        private bool _跳跃长按;

        // 记录最近一次按下的水平方向：1=右，-1=左，0=无
        private int _最近按下水平 = 0;

        // 自定义动作 -> 是否在本帧被按下
        private Dictionary<string, bool> _动作按下 = new Dictionary<string, bool>();

        // 记录组合动作上次触发时间，避免在窗口内重复触发
        private Dictionary<string, float> _组合上次触发 = new Dictionary<string, float>();

        // 保存最近一段时间的按键事件
        private struct KeyEvent { public KeyCode key; public float time; }
        private readonly List<KeyEvent> _最近按键事件 = new List<KeyEvent>();
        // 缓存最长的触发窗口，以便及时清理旧事件
        private float _最大组合窗口 = 0.5f;

        /// <summary>
        /// Awake：预初始化
        /// </summary>
        protected void Awake()
        {
            if (Instance != null && Instance != this)
            {
                // 若已有单例，尝试将当前对象的自定义按键合并过去，避免配置丢失
                if (自定义按键 != null && 自定义按键.Count > 0)
                {
                    foreach (var bind in 自定义按键)
                    {
                        if (!Instance.自定义按键.Exists(b => b.动作名 == bind.动作名))
                        {
                            Instance.自定义按键.Add(bind);
                        }
                    }
                    // 合并组合按键
                    if (组合按键 != null && 组合按键.Count > 0)
                    {
                        foreach (var cb in 组合按键)
                        {
                            if (!Instance.组合按键.Exists(c => c.动作名 == cb.动作名))
                            {
                                Instance.组合按键.Add(cb);
                            }
                        }
                    }
                    if (Instance.调试模式)
                    {
                        Debug.LogWarning($"[输入管理器] 检测到场景中存在多个输入管理器，已合并自定义按键后销毁重复对象 {name}。");
                    }
                }
                else if (调试模式)
                {
                    Debug.LogWarning($"[输入管理器] 检测到重复的输入管理器 {name}，但当前对象未配置自定义按键，将直接销毁。");
                }

                Destroy(gameObject);
                return;
            }

            Instance = this;
            DontDestroyOnLoad(gameObject);
            if (调试模式)
            {
                Debug.Log($"[输入管理器] 初始化完成，包含自定义按键 {自定义按键.Count} 项。");
            }

            // 预计算组合按键最大窗口
            if (组合按键 != null && 组合按键.Count > 0)
            {
                _最大组合窗口 = 组合按键.Max(c => c.最大触发间隔) + 0.1f;
            }

            预初始化();
        }

        /// <summary>
        /// Start：初始化输入模式
        /// </summary>
        protected void Start()
        {
            初始化();
        }

        /// <summary>
        /// 预初始化按钮与轴
        /// </summary>
        protected void 预初始化()
        {
            初始化按钮();
            初始化轴();
        }

        /// <summary>
        /// 初始化输入模式
        /// </summary>
        protected void 初始化()
        {
            检测输入模式();
        }

        /// <summary>
        /// 检测输入模式（移动端/桌面端自动切换）
        /// </summary>
        public void 检测输入模式()
        {
            // 可根据平台自动切换移动/桌面输入
        }

        /// <summary>
        /// 初始化所有按钮
        /// </summary>
        protected void 初始化按钮()
        {
            // 按钮注册逻辑后续补全
        }

        /// <summary>
        /// 初始化所有轴
        /// </summary>
        protected void 初始化轴()
        {
            // 轴注册逻辑后续补全
        }

        /// <summary>
        /// 每帧输入采样
        /// </summary>
        void Update()
        {
            if (!输入检测激活)
            {
                清零输入();
                return;
            }

            float x = Input.GetAxisRaw("Horizontal");
            float z = Input.GetAxisRaw("Vertical");

            // Horizontal 回退与优先逻辑
            bool leftKey = Input.GetKey(左键);
            bool rightKey = Input.GetKey(右键);

            // 记录最近一次按下
            if (Input.GetKeyDown(左键)) { _最近按下水平 = -1; 记录按键(左键); }
            if (Input.GetKeyDown(右键)) { _最近按下水平 = 1; 记录按键(右键); }

            if (Mathf.Approximately(x, 0f))
            {
                if (leftKey && rightKey)
                {
                    x = _最近按下水平;
                }
                else if (leftKey ^ rightKey)
                {
                    x = leftKey ? -1f : 1f;
                }
            }

            // Vertical 回退
            if (Mathf.Approximately(z, 0f))
            {
                bool upKey = Input.GetKey(上键);
                bool downKey = Input.GetKey(下键);
                if (upKey ^ downKey)
                {
                    z = upKey ? 1f : -1f;
                }
            }

            _移动向量 = new Vector3(x, 0, z);

            // 应用阈值过滤
            if (Mathf.Abs(_移动向量.x) < 移动阈值.x) _移动向量.x = 0;
            if (Mathf.Abs(_移动向量.z) < 移动阈值.y) _移动向量.z = 0;
            _移动向量 = _移动向量.normalized;

            _跳跃按下 = Input.GetKeyDown(跳跃键);
            if (_跳跃按下) 记录按键(跳跃键);
            _跳跃长按 = Input.GetKey(跳跃键);

            // 处理自定义按键
            foreach (var bind in 自定义按键)
            {
                if (!_动作按下.ContainsKey(bind.动作名))
                {
                    _动作按下.Add(bind.动作名, false);
                }
                bool down = Input.GetKeyDown(bind.键);
                _动作按下[bind.动作名] = down;
                if (down) 记录按键(bind.键);

                if (调试模式)
                {
                    // 调试：打印KeyCode类型和值
                    Debug.Log($"[自定义按键调试] 动作:{bind.动作名} 绑定KeyCode:{bind.键} ({(int)bind.键}) 类型:{bind.键.GetType()} Input.GetKeyDown={down}");

                    bool held = Input.GetKey(bind.键);
                    if (down)
                    {
                        Debug.Log($"[输入管理器] 动作 {bind.动作名} KeyDown=true Held={held}");
                    }
                    else if (held && Time.frameCount % 60 == 0)
                    {
                        Debug.Log($"[输入管理器] 动作 {bind.动作名} Held");
                    }
                }
            }

            // ========== 组合按键检测 ==========
            if (组合按键 != null && 组合按键.Count > 0)
            {
                // 清理过期事件
                float threshold = Time.time - _最大组合窗口;
                _最近按键事件.RemoveAll(e => e.time < threshold);

                // 按键序列长度降序，优先检测长连击（如 J+J+J 比 J+J 优先）
                var orderedCombos = 组合按键.OrderByDescending(c => c.键序列 != null ? c.键序列.Count : 0).ToList();

                // 记录本帧触发的组合，稍后用于屏蔽单键
                List<组合按键绑定> 本帧触发组合 = null;

                foreach (var combo in orderedCombos)
                {
                    if (!_动作按下.ContainsKey(combo.动作名))
                        _动作按下.Add(combo.动作名, false);

                    if (检测组合触发(combo))
                    {
                        if (调试模式)
                            Debug.Log($"[输入管理器] 组合动作 {combo.动作名} 预触发");

                        // 收集触发
                        if (本帧触发组合 == null) 本帧触发组合 = new List<组合按键绑定>();
                        本帧触发组合.Add(combo);
                    }
                }

                if (本帧触发组合 != null && 本帧触发组合.Count > 0)
                {
                    // 只保留最长的组合，避免短组合抢占
                    int maxLen = 本帧触发组合.Max(c => c.键序列 != null ? c.键序列.Count : 0);
                    var 最终触发组合 = 本帧触发组合.Where(c => (c.键序列 != null ? c.键序列.Count : 0) == maxLen);

                    foreach (var combo in 最终触发组合)
                    {
                        float cd = combo.冷却时长 > 0f ? combo.冷却时长 : combo.最大触发间隔;
                        if (!_组合上次触发.TryGetValue(combo.动作名, out float last) || Time.time - last > cd)
                        {
                            _动作按下[combo.动作名] = true;
                            _组合上次触发[combo.动作名] = Time.time;
                            if (调试模式)
                                Debug.Log($"[输入管理器] 组合动作 {combo.动作名} 最终触发（长度 {maxLen}）");

                            // 不立即移除事件，保留给更长连击检测，重复触发由冷却时长限制
                        }
                    }

                    // ===== 组合触发屏蔽单键 =====
                    if (组合触发屏蔽单键)
                    {
                        foreach (var cb in 最终触发组合)
                        {
                            foreach (var key in cb.键序列)
                            {
                                // 找到所有使用该Key的自定义单键动作并屏蔽本帧触发
                                foreach (var bind in 自定义按键)
                                {
                                    if (bind.键 == key && _动作按下.ContainsKey(bind.动作名))
                                    {
                                        _动作按下[bind.动作名] = false;
                                    }
                                }
                            }
                        }
                    }

                    // 注意：不在此清理事件，保留记录以便更长连击继续检测。
                }
            }
        }

        /// <summary>
        /// LateUpdate：重置一次性输入
        /// </summary>
        void LateUpdate()
        {
            // 单帧触发类按钮在LateUpdate清零，避免多次使用
            _跳跃按下 = false;

            // 清零自定义按键的单帧触发
            if (_动作按下.Count > 0)
            {
                var keys = _动作按下.Keys.ToList();
                foreach (var k in keys)
                    _动作按下[k] = false;
            }
        }

        #region 对外访问接口
        public Vector3 获取移动向量() => _移动向量;
        public bool 获取跳跃按下() => _跳跃按下;
        public bool 获取跳跃长按() => _跳跃长按;
        public bool 获取冲击按下() => 获取动作按下("Dash");
        #endregion

        /// <summary>
        /// 失去焦点/禁用输入时清零状态
        /// </summary>
        private void 清零输入()
        {
            _移动向量 = Vector3.zero;
            _跳跃按下 = _跳跃长按 = false;
            if (_动作按下 != null)
            {
                _动作按下.Clear();
            }
        }

        /// <summary>
        /// 查询指定动作名是否在本帧被按下
        /// </summary>
        public bool 获取动作按下(string 动作名)
        {
            return _动作按下.TryGetValue(动作名, out bool v) && v;
        }

        // 记录按下事件
        private void 记录按键(KeyCode key)
        {
            _最近按键事件.Add(new KeyEvent { key = key, time = Time.time });
        }

        /// <summary>
        /// 检测某个组合按键是否在最近事件中被触发
        /// </summary>
        private bool 检测组合触发(组合按键绑定 combo)
        {
            if (combo == null || combo.键序列 == null || combo.键序列.Count == 0) return false;

            float windowStart = Time.time - combo.最大触发间隔;

            if (combo.忽略顺序)
            {
                // 同时/无序：要求窗口内包含全部键
                foreach (var key in combo.键序列)
                {
                    if (!_最近按键事件.Exists(e => e.key == key && e.time >= windowStart))
                        return false;
                }
                return true;
            }
            else
            {
                // 顺序严格：从后往前匹配
                int index = combo.键序列.Count - 1;
                float firstTime = 0f, lastTime = 0f;
                for (int i = _最近按键事件.Count - 1; i >= 0 && index >= 0; i--)
                {
                    if (_最近按键事件[i].time < windowStart) break;
                    if (_最近按键事件[i].key == combo.键序列[index])
                    {
                        if (lastTime == 0f) lastTime = _最近按键事件[i].time;
                        firstTime = _最近按键事件[i].time;
                        index--;
                    }
                }
                if (index < 0 && (lastTime - firstTime) <= combo.最大触发间隔)
                {
                    return true;
                }
                return false;
            }
        }

        void OnValidate()
        {
            if (组合按键 != null && 组合按键.Count > 0)
            {
                _最大组合窗口 = 组合按键.Max(c => c.最大触发间隔) + 0.1f;
            }
            else
            {
                _最大组合窗口 = 0.5f;
            }
        }
    }
} 