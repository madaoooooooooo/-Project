using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

namespace 赛博西游.管理器
{
    /// <summary>
    /// 赛博西游全局事件类型
    /// </summary>
    public enum 游戏事件类型
    {
        角色生成开始,
        关卡开始,
        关卡完成,
        关卡结束,
        暂停,
        取消暂停,
        玩家死亡,
        生成完成,
        重生开始,
        重生完成,
        获得星星,
        游戏结束,
        角色交换,
        角色切换,
        刷新界面,
        切换暂停,
        加载下一个场景,
        无菜单暂停
    }

    /// <summary>
    /// 赛博西游全局事件结构体
    /// </summary>
    public struct 游戏事件
    {
        public 游戏事件类型 事件类型;
        public object 来源角色;

        public 游戏事件(游戏事件类型 eventType, object originCharacter)
        {
            事件类型 = eventType;
            来源角色 = originCharacter;
        }

        static 游戏事件 e;
        public static void 触发(游戏事件类型 eventType, object originCharacter)
        {
            e.事件类型 = eventType;
            e.来源角色 = originCharacter;
            // 这里应调用全局事件管理器
        }
    }

    /// <summary>
    /// 分数操作方式
    /// </summary>
    public enum 分数操作方式
    {
        增加,
        设定
    }

    /// <summary>
    /// 分数事件结构体
    /// </summary>
    public struct 分数事件
    {
        public 分数操作方式 操作方式;
        public int 分数值;
        public 分数事件(分数操作方式 method, int value)
        {
            操作方式 = method;
            分数值 = value;
        }
        static 分数事件 e;
        public static void 触发(分数操作方式 method, int value)
        {
            e.操作方式 = method;
            e.分数值 = value;
            // 这里应调用全局事件管理器
        }
    }

    /// <summary>
    /// 暂停方式
    /// </summary>
    public enum 暂停方式
    {
        菜单暂停,
        无菜单暂停
    }

    /// <summary>
    /// 关卡入口点存储
    /// </summary>
    public class 入口点存储
    {
        public string 关卡名;
        public int 入口索引;
        public object 朝向;
        public 入口点存储(string levelName, int entryIndex, object facingDirection)
        {
            关卡名 = levelName;
            入口索引 = entryIndex;
            朝向 = facingDirection;
        }
    }

    /// <summary>
    /// 游戏管理器，负责全局分数、暂停、生命等管理
    /// </summary>
    [AddComponentMenu("赛博西游/管理器/游戏管理器")]
    public class 游戏管理器 : MonoBehaviour
    {
        [Tooltip("目标帧率")]
        public int 目标帧率 = 300;

        [Header("生命设置")]
        [Tooltip("最大生命数")]
        public int 最大生命 = 0;
        [Tooltip("当前生命数")]
        public int 当前生命 = 0;

        [Header("场景绑定")]
        [Tooltip("游戏结束时跳转的场景名")]
        public string 游戏结束场景;

        [Header("分数")]
        [Tooltip("当前分数")]
        public int 分数;

        [Header("暂停")]
        [Tooltip("打开背包时是否自动暂停")]
        public bool 打开背包自动暂停 = true;
        public bool 已暂停 { get; set; }
        public bool 已存储地图位置 { get; set; }
        public Vector2 地图位置 { get; set; }
        public object 持久角色 { get; set; }
        [Tooltip("入口点存储列表")]
        public List<入口点存储> 入口点列表;
        public object 已存储角色 { get; set; }

        // 内部字段
        protected bool _背包已打开 = false;
        protected bool _暂停菜单已打开 = false;
        protected int _初始最大生命;
        protected int _初始当前生命;

        /// <summary>
        /// 初始化入口点列表
        /// </summary>
        protected void Awake()
        {
            入口点列表 = new List<入口点存储>();
        }

        /// <summary>
        /// 设置目标帧率，初始化生命
        /// </summary>
        protected void Start()
        {
            Application.targetFrameRate = 目标帧率;
            _初始当前生命 = 当前生命;
            _初始最大生命 = 最大生命;
        }

        /// <summary>
        /// 重置游戏管理器
        /// </summary>
        public void 重置()
        {
            分数 = 0;
            已暂停 = false;
        }

        /// <summary>
        /// 失去一条生命
        /// </summary>
        public void 失去生命()
        {
            当前生命--;
        }

        /// <summary>
        /// 获得生命
        /// </summary>
        public void 获得生命(int 数量)
        {
            当前生命 += 数量;
            if (当前生命 > 最大生命)
            {
                当前生命 = 最大生命;
            }
        }

        /// <summary>
        /// 增加最大生命，并可选增加当前生命
        /// </summary>
        public void 增加最大生命(int 数量, bool 同时增加当前)
        {
            最大生命 += 数量;
            if (同时增加当前)
            {
                当前生命 += 数量;
            }
        }

        /// <summary>
        /// 重置生命为初始值
        /// </summary>
        public void 重置生命()
        {
            当前生命 = _初始当前生命;
            最大生命 = _初始最大生命;
        }

        /// <summary>
        /// 增加分数
        /// </summary>
        public void 增加分数(int 数量)
        {
            分数 += 数量;
            // 可调用界面刷新
        }

        /// <summary>
        /// 设定分数
        /// </summary>
        public void 设定分数(int 数量)
        {
            分数 = 数量;
            // 可调用界面刷新
        }

        /// <summary>
        /// 暂停游戏
        /// </summary>
        public void 暂停(暂停方式 方式 = 暂停方式.菜单暂停, bool 已暂停时取消 = true)
        {
            if ((方式 == 暂停方式.菜单暂停) && _背包已打开)
            {
                return;
            }
            if (Time.timeScale > 0.0f)
            {
                Time.timeScale = 0f;
                已暂停 = true;
                _暂停菜单已打开 = (方式 == 暂停方式.菜单暂停);
            }
            else
            {
                if (已暂停时取消)
                {
                    取消暂停(方式);
                }
            }
        }

        /// <summary>
        /// 取消暂停
        /// </summary>
        public void 取消暂停(暂停方式 方式 = 暂停方式.菜单暂停)
        {
            Time.timeScale = 1f;
            已暂停 = false;
            if (_暂停菜单已打开)
            {
                _暂停菜单已打开 = false;
            }
            if (_背包已打开)
            {
                _背包已打开 = false;
            }
        }

        /// <summary>
        /// 存储关卡入口点
        /// </summary>
        public void 存储入口点(string 关卡名, int 入口索引, object 朝向)
        {
            if (入口点列表.Count > 0)
            {
                foreach (入口点存储 点 in 入口点列表)
                {
                    if (点.关卡名 == 关卡名)
                    {
                        点.入口索引 = 入口索引;
                        return;
                    }
                }
            }
            入口点列表.Add(new 入口点存储(关卡名, 入口索引, 朝向));
        }

        /// <summary>
        /// 获取关卡入口点
        /// </summary>
        public 入口点存储 获取入口点(string 关卡名)
        {
            if (入口点列表.Count > 0)
            {
                foreach (入口点存储 点 in 入口点列表)
                {
                    if (点.关卡名 == 关卡名)
                    {
                        return 点;
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// 清除指定关卡入口点
        /// </summary>
        public void 清除入口点(string 关卡名)
        {
            if (入口点列表.Count > 0)
            {
                for (int i = 入口点列表.Count - 1; i >= 0; i--)
                {
                    if (入口点列表[i].关卡名 == 关卡名)
                    {
                        入口点列表.RemoveAt(i);
                    }
                }
            }
        }

        /// <summary>
        /// 清除所有入口点
        /// </summary>
        public void 清除所有入口点()
        {
            入口点列表.Clear();
        }

        /// <summary>
        /// 启用时注册事件监听
        /// </summary>
        protected void OnEnable()
        {
            // 这里应注册全局事件监听，如：
            // 事件中心.注册<游戏事件>(On游戏事件);
            // 事件中心.注册<分数事件>(On分数事件);
        }

        /// <summary>
        /// 禁用时注销事件监听
        /// </summary>
        protected void OnDisable()
        {
            // 这里应注销全局事件监听，如：
            // 事件中心.注销<游戏事件>(On游戏事件);
            // 事件中心.注销<分数事件>(On分数事件);
        }

        /// <summary>
        /// 响应全局游戏事件
        /// </summary>
        public void On游戏事件(游戏事件 e)
        {
            switch (e.事件类型)
            {
                case 游戏事件类型.切换暂停:
                    if (已暂停)
                        游戏事件.触发(游戏事件类型.取消暂停, null);
                    else
                        游戏事件.触发(游戏事件类型.暂停, null);
                    break;
                case 游戏事件类型.暂停:
                    暂停();
                    break;
                case 游戏事件类型.取消暂停:
                    取消暂停();
                    break;
                case 游戏事件类型.无菜单暂停:
                    暂停(暂停方式.无菜单暂停, false);
                    break;
            }
        }

        /// <summary>
        /// 响应分数事件
        /// </summary>
        public void On分数事件(分数事件 e)
        {
            switch (e.操作方式)
            {
                case 分数操作方式.设定:
                    设定分数(e.分数值);
                    break;
                case 分数操作方式.增加:
                    增加分数(e.分数值);
                    break;
            }
        }

        /// <summary>
        /// 重置所有存档
        /// </summary>
        public void 重置所有存档()
        {
            // 这里应调用存档管理器删除所有存档
            // 存档管理器.删除存档("InventoryEngine");
            // 存档管理器.删除存档("TopDownEngine");
            // 存档管理器.删除存档("MMAchievements");
        }

        /// <summary>
        /// 存储选中角色
        /// </summary>
        public void 存储选中角色(object 角色)
        {
            已存储角色 = 角色;
        }

        /// <summary>
        /// 清除选中角色
        /// </summary>
        public void 清除选中角色()
        {
            已存储角色 = null;
        }

        /// <summary>
        /// 设置持久角色
        /// </summary>
        public void 设置持久角色(object 角色)
        {
            持久角色 = 角色;
        }

        /// <summary>
        /// 销毁持久角色
        /// </summary>
        public void 销毁持久角色()
        {
            持久角色 = null;
            // 如有GameObject可在此销毁
        }
    }
} 