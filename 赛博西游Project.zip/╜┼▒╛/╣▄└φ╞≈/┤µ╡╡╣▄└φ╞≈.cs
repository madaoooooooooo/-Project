using UnityEngine;
using System.Collections;
using System.IO;

namespace 赛博西游.管理器
{
    /// <summary>
    /// 存档管理器，支持对象的保存、读取、删除、清空等操作。
    /// </summary>
    public static class 存档管理器
    {
        // 默认存档方法（可扩展为二进制、json等）
        public static I存档方法 存取方法 = new 二进制存档方法();
        private const string _基础目录 = "/MMData/";
        private const string _默认文件夹 = "存档管理器";

        /// <summary>
        /// 获取存档路径
        /// </summary>
        static string 获取存档路径(string 文件夹 = _默认文件夹)
        {
            string 路径 = Application.persistentDataPath + _基础目录;
#if UNITY_EDITOR
            路径 = Application.dataPath + _基础目录;
#endif
            路径 = 路径 + 文件夹 + "/";
            return 路径;
        }

        /// <summary>
        /// 保存对象到磁盘
        /// </summary>
        public static void 保存(object 对象, string 文件名, string 文件夹 = _默认文件夹)
        {
            string 路径 = 获取存档路径(文件夹);
            if (!Directory.Exists(路径))
            {
                Directory.CreateDirectory(路径);
            }
            FileStream 文件 = File.Create(路径 + 文件名);
            存取方法.保存(对象, 文件);
            文件.Close();
        }

        /// <summary>
        /// 读取对象
        /// </summary>
        public static object 读取(System.Type 类型, string 文件名, string 文件夹 = _默认文件夹)
        {
            string 路径 = 获取存档路径(文件夹);
            string 完整名 = 路径 + 文件名;
            if (!Directory.Exists(路径) || !File.Exists(完整名))
            {
                return null;
            }
            FileStream 文件 = File.Open(完整名, FileMode.Open, FileAccess.Read, FileShare.Read);
            object 返回对象 = 存取方法.读取(类型, 文件);
            文件.Close();
            return 返回对象;
        }

        /// <summary>
        /// 删除单个存档
        /// </summary>
        public static void 删除存档(string 文件名, string 文件夹 = _默认文件夹)
        {
            string 路径 = 获取存档路径(文件夹);
            if (File.Exists(路径 + 文件名))
            {
                File.Delete(路径 + 文件名);
            }
            if (File.Exists(路径 + 文件名 + ".meta"))
            {
                File.Delete(路径 + 文件名 + ".meta");
            }
        }

        /// <summary>
        /// 删除整个存档文件夹
        /// </summary>
        public static void 删除存档文件夹(string 文件夹 = _默认文件夹)
        {
            string 路径 = 获取存档路径(文件夹);
            if (Directory.Exists(路径))
            {
                删除目录(路径);
            }
        }

        /// <summary>
        /// 删除所有存档
        /// </summary>
        public static void 删除所有存档()
        {
            string 路径 = 获取存档路径("");
            if (路径.EndsWith("/"))
            {
                路径 = 路径.Substring(0, 路径.Length - 1);
            }
            if (Directory.Exists(路径))
            {
                删除目录(路径);
            }
        }

        /// <summary>
        /// 删除目录及其内容
        /// </summary>
        public static void 删除目录(string 目录)
        {
            string[] 文件列表 = Directory.GetFiles(目录);
            string[] 子目录列表 = Directory.GetDirectories(目录);
            foreach (string 文件 in 文件列表)
            {
                File.SetAttributes(文件, FileAttributes.Normal);
                File.Delete(文件);
            }
            foreach (string 子目录 in 子目录列表)
            {
                删除目录(子目录);
            }
            Directory.Delete(目录, false);
            if (File.Exists(目录 + ".meta"))
            {
                File.Delete(目录 + ".meta");
            }
        }
    }

    /// <summary>
    /// 存档方法接口
    /// </summary>
    public interface I存档方法
    {
        void 保存(object 对象, FileStream 文件);
        object 读取(System.Type 类型, FileStream 文件);
    }

    /// <summary>
    /// 二进制存档方法实现
    /// </summary>
    public class 二进制存档方法 : I存档方法
    {
        public void 保存(object 对象, FileStream 文件)
        {
            var 格式化器 = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
            格式化器.Serialize(文件, 对象);
        }
        public object 读取(System.Type 类型, FileStream 文件)
        {
            var 格式化器 = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
            return 格式化器.Deserialize(文件);
        }
    }
} 