using UnityEngine;
using 赛博西游.管理器;
using 赛博西游Project.角色;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Spine.Unity;

namespace 赛博西游.角色
{
    /// <summary>
    /// 玩家控制器：负责采集输入并驱动移动能力与动画。
    /// </summary>
    [RequireComponent(typeof(移动能力))]
    [RequireComponent(typeof(角色基类))]
    public class 玩家控制器 : MonoBehaviour
    {
        private 移动能力 _移动能力;
        private 角色基类 _角色基类;
        private 输入管理器 _输入管理器;

        [Header("移动能力参数代理")] // 方案A：在玩家控制器统一暴露
        public float 移动速度 = 5f;
        public 移动能力.跳跃参数组 跳跃参数 = new 移动能力.跳跃参数组();
        public 移动能力.跳跃手感组 跳跃手感优化 = new 移动能力.跳跃手感组();
        public 移动能力.冲击翻滚组 冲击翻滚参数 = new 移动能力.冲击翻滚组();

        // ===== 动作-动画映射 =====
        [System.Serializable]
        public class 动作动画绑定
        {
            public string 动作名 = "Attack1";  // 输入管理器中的动作名
            public string 动画槽 = "Attack1";    // 角色动画槽名
            public bool 循环 = false;              // 动画是否循环
            [Tooltip("播放该动画时锁定Idle/Move切换的时长(秒)，0表示不锁定")]
            public float 锁定时长 = 0.4f;
        }

        [Header("动作-动画绑定")]
        public List<动作动画绑定> 动作动画列表 = new List<动作动画绑定>();

        [Header("调试")]
        public bool 调试模式 = false;

        // ========== 动作队列 ==========
        private Queue<string> _动作队列 = new Queue<string>(); // 组合/单键动作缓冲
        private bool _动作进行中 = false; // true 表示当前有一次性动作在播，等待Complete后释放
        private float _动作锁定计时器 = 0f; // 额外计时器，防止End未触发导致卡死

        // 记录一次性动作(非循环)槽，后续返回Idle/Move时用
        private HashSet<string> _一次性动作集合 = new HashSet<string>();

        // 在编辑器和运行时保持绑定与输入动作同步
        void SyncBindingsFromInputManager()
        {
            // 强制用FindObjectOfType兜底，确保编辑器下也能获取到输入管理器
            var im = GameObject.FindObjectOfType<输入管理器>() ?? 输入管理器.Instance ?? _输入管理器;
            if (im == null)
            {
                Debug.LogWarning("[玩家控制器] 未找到输入管理器，无法同步动作动画绑定！");
                return;
            }

            // 先移除所有不在输入管理器自定义/组合按键中的绑定
            动作动画列表.RemoveAll(b =>
                !im.自定义按键.Exists(k => k.动作名 == b.动作名) &&
                !(im.组合按键 != null && im.组合按键.Exists(c => c.动作名 == b.动作名)));

            // 再补充缺失的绑定（自定义 + 组合）
            IEnumerable<string> allActionNames = im.自定义按键.Select(a => a.动作名);
            if (im.组合按键 != null)
                allActionNames = allActionNames.Concat(im.组合按键.Select(c => c.动作名));

            foreach (var action in allActionNames)
            {
                if (!动作动画列表.Exists(b => b.动作名 == action))
                {
                    动作动画列表.Add(new 动作动画绑定 { 动作名 = action, 动画槽 = action, 循环 = false });
                }
            }

            // 更新一次性动作集合（标记循环==false）
            _一次性动作集合.Clear();
            foreach (var bind in 动作动画列表)
            {
                if (!bind.循环)
                    _一次性动作集合.Add(bind.动画槽);
            }
        }

        void OnValidate()
        {
            // 编辑器中属性变更时自动同步
            if (_移动能力 == null) _移动能力 = GetComponent<移动能力>();
            if (_移动能力 != null)
            {
                _移动能力.ApplyExternalParameters(移动速度, 跳跃参数, 跳跃手感优化, 冲击翻滚参数);
            }

            SyncBindingsFromInputManager();
        }

        void Awake()
        {
            _移动能力 = GetComponent<移动能力>();
            _角色基类 = GetComponent<角色基类>();

            _输入管理器 = 输入管理器.Instance; // 可能暂时为 null

            // 初始同步代理参数
            _移动能力.ApplyExternalParameters(移动速度, 跳跃参数, 跳跃手感优化, 冲击翻滚参数);

            SyncBindingsFromInputManager();

            // 初始化一次性动作集合（不循环的动作）
            _一次性动作集合.Clear();
            foreach (var b in 动作动画列表)
            {
                if (!b.循环)
                    _一次性动作集合.Add(b.动画槽);
            }
        }

        // 修改为协程，延迟一帧后再同步输入管理器
        System.Collections.IEnumerator Start()
        {
            yield return null; // 等待一帧，确保输入管理器已初始化
            _输入管理器 = 输入管理器.Instance;
            if (_输入管理器 == null)
            {
                Debug.LogError("[玩家控制器] 仍未找到输入管理器！\n1) 在Hierarchy中新建空物体(如 GameSystems)\n2) 将输入管理器脚本拖到该物体上\n3) 确保无重复单例。\n完成后重新运行场景。 ");
            }
            // 再次同步，确保运行时最新按键列表
            SyncBindingsFromInputManager();
        }

        void Update()
        {
            if (_输入管理器 == null || !_输入管理器.输入检测激活)
            {
                if (调试模式)
                    Debug.Log("[调试] 输入管理器未激活或未找到");
                return; // 输入不可用，直接退出
            }

            Vector3 moveInput = _输入管理器.获取移动向量();
            bool jumpDown = _输入管理器.获取跳跃按下();
            bool jumpHeld = _输入管理器.获取跳跃长按();
            bool dashDown = _输入管理器.获取冲击按下();

            // 将输入传递给移动能力
            _移动能力.设置输入向量(moveInput);
            if (jumpDown)
            {
                _移动能力.请求跳跃();
                _角色基类?.触发跳跃动画();
            }
            _移动能力.设置持续跳跃(jumpHeld);
            if (dashDown) _移动能力.请求冲击();

            // 角色基类内已根据速度自动切换 Idle/Move 动画槽，这里仅处理自定义动作动画
            if (_角色基类 != null)
            {
                // 确保绑定列表实时跟随输入管理器变化（支持运行时调整）
                SyncBindingsFromInputManager();

                foreach (var bind in 动作动画列表)
                {
                    bool keyDown = _输入管理器.获取动作按下(bind.动作名);
                    if (!keyDown) continue;

                    // if (调试模式)
                    //     Debug.Log($"[玩家控制器] 捕获动作 {bind.动作名} => 槽 {bind.动画槽}");

                    // 动作进行中：排入队列
                    if (_动作进行中)
                    {
                        // 缓冲动作（连击优先，但单键也允许）
                        EnqueueBufferedAction(bind);
                        continue;
                    }

                    // 空闲可立即播放
                    播放动作(bind);
                }

                // 若当前无动作进行且队列中还有动作，尝试播放下一条
                if (!_动作进行中 && _动作队列.Count > 0)
                {
                    string nextSlot = _动作队列.Dequeue();
                    var pendingBind = 动作动画列表.Find(b => b.动画槽 == nextSlot);
                    if (pendingBind != null)
                    {
                        播放动作(pendingBind);
                    }
                }
            }

            if (_动作锁定计时器 > 0f)
            {
                _动作锁定计时器 -= Time.deltaTime;
                if (_动作锁定计时器 <= 0f)
                {
                    // if (_动作进行中 && 调试模式)
                    //     Debug.Log("[动作] 锁定计时器到期，强制解锁");

                    _动作进行中 = false;
                }
            }
        }

        // 播放动作并根据是否一次性设置_complete回调
        private void 播放动作(动作动画绑定 bind)
        {
            if (bind == null) return;

            // 新增：尝试触发一次攻击判定并打印调试
            var attackAbilityTmp = GetComponent<赛博西游Project.角色.攻击能力>();
            if (attackAbilityTmp != null)
            {
                Debug.Log($"[攻击] {gameObject.name} 发起攻击，基础伤害 {attackAbilityTmp.伤害}");
                attackAbilityTmp.尝试攻击();
            }

            // 先暂不锁定，稍后根据动画时长与自定义值综合计算

            bool once = !bind.循环 || _一次性动作集合.Contains(bind.动画槽);

            var animProxy = _角色基类?.动画代理;
            if (animProxy == null)
                return;

            if (once)
            {
                _动作进行中 = true;
                // 通过Spine返回TrackEntry，从而注册Complete
                var skeleton = animProxy.GetComponent<SkeletonAnimation>();
                if (skeleton != null)
                {
                    var animName = animProxy.取动画名(bind.动画槽);
                    if (string.IsNullOrEmpty(animName))
                    {
                        // 未找到动画名，直接解锁
                        _动作进行中 = false;
                    }
                    else
                    {
                        var entry = skeleton.AnimationState.SetAnimation(0, animName, false);
                        // 计算锁定时长：自定义锁定 vs 动画长度
                        float lockTime = bind.锁定时长;
                        if (entry != null && entry.Animation != null)
                        {
                            float duration = entry.Animation.Duration;
                            if (duration > lockTime) lockTime = duration;
                        }
                        if (lockTime > 0f)
                        {
                            _角色基类.锁定IdleMove切换(lockTime);
                            _动作锁定计时器 = lockTime; // 额外计时器，用于容错
                        }

                        entry.Complete += (e) =>
                        {
                            // 动画播放完毕，解除动作占用
                            _动作进行中 = false;
                            _角色基类?.回到基础Idle或Move();
                        };

                        // 不再监听 End，统一交给锁定计时器兜底
                    }
                }
                else
                {
                    // 如果SkeletonAnimation不存在，回退到代理切换，但无法获Complete，立即解锁
                    animProxy.切换动画槽(bind.动画槽, bind.循环);
                    _动作进行中 = false;
                }
            }
            else
            {
                animProxy.切换动画槽(bind.动画槽, bind.循环);
            }
        }

        // 缓冲动作到队列，避免连续重复
        private void EnqueueBufferedAction(动作动画绑定 bind)
        {
            const int MaxBuffer = 5; // 队列上限，防止无限堆积

            if (_动作队列.Count >= MaxBuffer)
                return;

            if (_动作队列.Count > 0 && _动作队列.Last() == bind.动画槽)
                return; // 避免重复入队

            _动作队列.Enqueue(bind.动画槽);

            // if (调试模式)
            //     ; // 原关于缓冲队列的Debug已移除
        }

        // Helper：判断一个动作名是否为组合(连击)动作
        private bool IsComboAction(string actionName)
        {
            var im = _输入管理器 ?? 输入管理器.Instance;
            if (im != null && im.组合按键 != null)
            {
                return im.组合按键.Exists(c => c.动作名 == actionName);
            }
            return false;
        }
    }
}
