using UnityEngine;

public class 摄像机背景设置器 : MonoBehaviour
{
    void Awake()
    {
        Camera mainCamera = Camera.main;
        if (mainCamera != null)
        {
            mainCamera.clearFlags = CameraClearFlags.SolidColor;
            mainCamera.backgroundColor = Color.black;
            Debug.Log("Camera background set to black solid color.");
        }
        else
        {
            Debug.LogError("Main Camera not found!");
        }
    }
}