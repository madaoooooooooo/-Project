using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems; // 用于事件系统接口
using System.Collections; // 用于协程

public class 继续游戏按钮配置器 : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public Button ContinueButton;
    public Text ButtonText;
    public int baseFontSize = 48; // 通过Inspector设置按钮文字的基准字体大小

    void Start()
    {
        // Get references to components
        ContinueButton = GetComponent<Button>();
        ButtonText = GetComponentInChildren<Text>();
        RectTransform rectTransform = GetComponent<RectTransform>();

        if (ButtonText != null)
        {
            Debug.Log("继续游戏按钮配置器: 成功获取到ButtonText组件. Text: " + ButtonText.text + ", Font Size: " + ButtonText.fontSize);
            ButtonText.fontSize = baseFontSize; // 初始字体大小设置为基准字体大小
            ButtonText.text = "继续游戏";
            ButtonText.color = Color.grey; // Grey out for disabled state
            ButtonText.alignment = TextAnchor.MiddleCenter;
            ButtonText.enabled = true; // Ensure text is enabled
            ButtonText.horizontalOverflow = HorizontalWrapMode.Overflow; // Prevent text clipping
            ButtonText.verticalOverflow = VerticalWrapMode.Overflow; // Prevent text clipping

            // Set text RectTransform to fill the button
            RectTransform textRectTransform = ButtonText.GetComponent<RectTransform>();
            if(textRectTransform != null)
            {
                textRectTransform.anchorMin = Vector2.zero;
                textRectTransform.anchorMax = Vector2.one;
                textRectTransform.sizeDelta = Vector2.zero;
                textRectTransform.anchoredPosition = Vector2.zero;
            }
            else
            {
                Debug.LogError("继续游戏按钮配置器: 未能获取到ButtonText的RectTransform组件!");
            }
        }
        else
        {
            Debug.LogError("继续游戏按钮配置器: 未能获取到ButtonText组件!");
        }

        if (rectTransform != null)
        {
            Debug.Log("继续游戏按钮配置器: 成功获取到RectTransform组件. Position: " + rectTransform.anchoredPosition + ", Size: " + rectTransform.sizeDelta);
            // Position the button below the start game button
            rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
            rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
            rectTransform.pivot = new Vector2(0.5f, 0.5f);
            rectTransform.anchoredPosition = new Vector2(0, -50); // Adjust Y position as needed
            rectTransform.sizeDelta = new Vector2(400, 100);
        }
        else
        {
            Debug.LogError("继续游戏按钮配置器: 未能获取到RectTransform组件!");
        }

        if (ContinueButton != null)
        {
            Debug.Log("继续游戏按钮配置器: 成功获取到Button组件.");
            ContinueButton.onClick.AddListener(OnContinueGameButtonClicked);
            ContinueButton.interactable = false; // Initially not clickable
        }
        else
        {
            Debug.LogError("继续游戏按钮配置器: 未能获取到Button组件!");
        }
    }

    void OnContinueGameButtonClicked()
    {
        Debug.Log("继续游戏按钮被点击！");
        StartCoroutine(FlashText(ButtonText)); // 启动文字闪烁协程
        // 这里可以添加继续游戏逻辑
    }

    // 鼠标进入事件
    public void OnPointerEnter(PointerEventData eventData)
    {
        Debug.Log("鼠标进入继续游戏按钮！");
        if (ContinueButton.interactable && ButtonText != null)
        {
            ButtonText.fontSize = baseFontSize + 10; // 鼠标悬停时字体变大
        }
    }

    // 鼠标离开事件
    public void OnPointerExit(PointerEventData eventData)
    {
        Debug.Log("鼠标离开继续游戏按钮！");
        if (ContinueButton.interactable && ButtonText != null)
        {
            ButtonText.fontSize = baseFontSize; // 鼠标离开时恢复基准字体大小
        }
    }

    // 文字闪烁协程
    IEnumerator FlashText(Text textToFlash)
    {
        if (textToFlash == null) yield break;

        Color originalColor = textToFlash.color;
        float flashDuration = 0.05f; // 每次闪烁的持续时间
        int flashCount = 3; // 闪烁次数

        for (int i = 0; i < flashCount; i++)
        {
            textToFlash.color = new Color(originalColor.r, originalColor.g, originalColor.b, 0); // 完全透明
            yield return new WaitForSeconds(flashDuration);
            textToFlash.color = originalColor; // 恢复原始颜色
            yield return new WaitForSeconds(flashDuration);
        }
    }
}