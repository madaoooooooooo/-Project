using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems; // 用于事件系统接口
using System.Collections; // 用于协程

public class 退出游戏按钮配置器 : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public Button ExitButton;
    public Text ButtonText;
    public int baseFontSize = 48; // 通过Inspector设置按钮文字的基准字体大小
    public CanvasGroup welcomeCanvasGroup; // 引用欢迎界面的CanvasGroup

    void Start()
    {
        // Get references to components
        ExitButton = GetComponent<Button>();
        ButtonText = GetComponentInChildren<Text>();
        RectTransform rectTransform = GetComponent<RectTransform>();

        // 获取父级CanvasGroup组件
        if (transform.parent != null)
        {
            welcomeCanvasGroup = transform.parent.GetComponent<CanvasGroup>();
            if (welcomeCanvasGroup == null)
            {
                Debug.LogError("退出游戏按钮配置器: 未能获取到父级CanvasGroup组件!");
            }
        }
        else
        {
            Debug.LogError("退出游戏按钮配置器: 按钮没有父级对象，无法获取CanvasGroup!");
        }

        if (ButtonText != null)
        {
            Debug.Log("退出游戏按钮配置器: 成功获取到ButtonText组件. Text: " + ButtonText.text + ", Font Size: " + ButtonText.fontSize);
            ButtonText.fontSize = baseFontSize; // 初始字体大小设置为基准字体大小
            ButtonText.text = "退出游戏";
            ButtonText.color = Color.white;
            ButtonText.alignment = TextAnchor.MiddleCenter;
            ButtonText.enabled = true;
            ButtonText.horizontalOverflow = HorizontalWrapMode.Overflow;
            ButtonText.verticalOverflow = VerticalWrapMode.Overflow;
            
            // Set text RectTransform to fill the button
            RectTransform textRectTransform = ButtonText.GetComponent<RectTransform>();
            if(textRectTransform != null)
            {
                textRectTransform.anchorMin = Vector2.zero;
                textRectTransform.anchorMax = Vector2.one;
                textRectTransform.sizeDelta = Vector2.zero;
                textRectTransform.anchoredPosition = Vector2.zero;
            }
            else
            {
                Debug.LogError("退出游戏按钮配置器: 未能获取到ButtonText的RectTransform组件!");
            }
        }
        else
        {
            Debug.LogError("退出游戏按钮配置器: 未能获取到ButtonText组件!");
        }

        if (rectTransform != null)
        {
            Debug.Log("退出游戏按钮配置器: 成功获取到RectTransform组件. Position: " + rectTransform.anchoredPosition + ", Size: " + rectTransform.sizeDelta);
            // Position the button below the continue game button
            rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
            rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
            rectTransform.pivot = new Vector2(0.5f, 0.5f);
            rectTransform.anchoredPosition = new Vector2(0, -150); // Adjust Y position as needed
            rectTransform.sizeDelta = new Vector2(400, 100);
        }
        else
        {
            Debug.LogError("退出游戏按钮配置器: 未能获取到RectTransform组件!");
        }

        if (ExitButton != null)
        {
            Debug.Log("退出游戏按钮配置器: 成功获取到Button组件.");
            ExitButton.onClick.AddListener(OnExitGameButtonClicked);

            // 移除颜色渐变点击效果设置
            // ColorBlock colors = ExitButton.colors;
            // colors.normalColor = new Color32(255, 255, 255, 255);
            // colors.highlightedColor = new Color32(240, 240, 240, 255);
            // colors.pressedColor = new Color32(200, 200, 200, 255);
            // colors.selectedColor = new Color32(240, 240, 240, 255);
            // colors.disabledColor = new Color32(200, 200, 200, 128);
            // ExitButton.colors = colors;
            // ExitButton.transition = Selectable.Transition.ColorTint;
        }
        else
        {
            Debug.LogError("退出游戏按钮配置器: 未能获取到Button组件!");
        }
    }

    void OnExitGameButtonClicked()
    {
        Debug.Log("退出游戏按钮被点击！");
        StartCoroutine(FlashTextAndFadeOutAndQuit(ButtonText)); // 启动文字闪烁、淡出和退出协程
    }

    // 鼠标进入事件
    public void OnPointerEnter(PointerEventData eventData)
    {
        Debug.Log("鼠标进入退出游戏按钮！");
        if (ButtonText != null)
        {
            ButtonText.fontSize = baseFontSize + 10; // 鼠标悬停时字体变大
        }
    }

    // 鼠标离开事件
    public void OnPointerExit(PointerEventData eventData)
    {
        Debug.Log("鼠标离开退出游戏按钮！");
        if (ButtonText != null)
        {
            ButtonText.fontSize = baseFontSize; // 鼠标离开时恢复基准字体大小
        }
    }

    // 文字闪烁、淡出并退出协程
    IEnumerator FlashTextAndFadeOutAndQuit(Text textToFlash)
    {
        // 先执行文字闪烁
        yield return StartCoroutine(FlashText(textToFlash));

        // 淡出CanvasGroup
        if (welcomeCanvasGroup != null)
        {
            float fadeDuration = 0.5f; // 淡出持续时间
            float startAlpha = welcomeCanvasGroup.alpha;
            float timer = 0f;

            Debug.Log("退出游戏按钮配置器: 开始淡出欢迎界面。");
            while (timer < fadeDuration)
            {
                timer += Time.deltaTime;
                welcomeCanvasGroup.alpha = Mathf.Lerp(startAlpha, 0f, timer / fadeDuration);
                yield return null;
            }
            welcomeCanvasGroup.alpha = 0f; // 确保完全透明

            Debug.Log("退出游戏按钮配置器: 欢迎界面淡出完成。准备退出应用程序。");
        }
        else
        {
            Debug.LogError("退出游戏按钮配置器: CanvasGroup引用为空，无法执行淡出！");
        }

        // 退出应用程序
        #if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
        #else
            Application.Quit();
        #endif
    }

    // 文字闪烁协程
    IEnumerator FlashText(Text textToFlash)
    {
        if (textToFlash == null) yield break;

        Color originalColor = textToFlash.color;
        float flashDuration = 0.05f; // 每次闪烁的持续时间
        int flashCount = 3; // 闪烁次数

        for (int i = 0; i < flashCount; i++)
        {
            textToFlash.color = new Color(originalColor.r, originalColor.g, originalColor.b, 0); // 完全透明
            yield return new WaitForSeconds(flashDuration);
            textToFlash.color = originalColor; // 恢复原始颜色
            yield return new WaitForSeconds(flashDuration);
        }
    }
}