using UnityEngine;
using UnityEngine.UI;

public class 画布配置器 : MonoBehaviour
{
    public Canvas TargetCanvas;
    public CanvasScaler TargetCanvasScaler;

    void Start()
    {
        TargetCanvas = GetComponent<Canvas>();
        TargetCanvasScaler = GetComponent<CanvasScaler>();

        if (TargetCanvas != null)
        {
            TargetCanvas.renderMode = RenderMode.ScreenSpaceCamera;
            // Find the Main Camera by its tag
            Camera mainCamera = Camera.main;
            if (mainCamera == null)
            {
                Debug.LogError("Main Camera not found! Please ensure it's tagged as 'MainCamera'.");
            }
            TargetCanvas.worldCamera = mainCamera;
        }

        if (TargetCanvasScaler != null)
        {
            TargetCanvasScaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            TargetCanvasScaler.referenceResolution = new Vector2(1920, 1080);
            TargetCanvasScaler.matchWidthOrHeight = 0.5f; // 0.5 means blend between width and height
        }
    }
}