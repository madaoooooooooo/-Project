using UnityEngine;
using UnityEngine.UI;

public class 游戏标题配置器 : MonoBehaviour
{
    public string gameTitle = "游戏标题"; // 通过Inspector设置游戏标题
    public float Y轴偏移 = -200f; // 调整此值以改变标题的垂直位置

    void Start()
    {
        Text titleText = GetComponent<Text>();
        RectTransform rectTransform = GetComponent<RectTransform>();

        if (titleText != null)
        {
            Debug.Log("游戏标题配置器: 成功获取到Text组件. Text: " + titleText.text + ", Font Size: " + titleText.fontSize);
            titleText.text = gameTitle; // 使用公共变量设置标题
            titleText.fontSize = 72;
            titleText.color = Color.white;
            titleText.alignment = TextAnchor.MiddleCenter;
            titleText.enabled = true;
            titleText.horizontalOverflow = HorizontalWrapMode.Overflow;
            titleText.verticalOverflow = VerticalWrapMode.Overflow;
        }
        else
        {
            Debug.LogError("游戏标题配置器: 未能获取到Text组件!");
        }

        if (rectTransform != null)
        {
            Debug.Log("游戏标题配置器: 成功获取到RectTransform组件. Position: " + rectTransform.anchoredPosition + ", Size: " + rectTransform.sizeDelta);
            rectTransform.anchorMin = new Vector2(0.5f, 1f);
            rectTransform.anchorMax = new Vector2(0.5f, 1f);
            rectTransform.pivot = new Vector2(0.5f, 1f);
            rectTransform.anchoredPosition = new Vector2(0, Y轴偏移); // 使用Y轴偏移调整位置
            rectTransform.sizeDelta = new Vector2(800, 150);
        }
        else
        {
            Debug.LogError("游戏标题配置器: 未能获取到RectTransform组件!");
        }
    }

    public void SetGameTitle(string newTitle)
    {
        Text titleText = GetComponent<Text>();
        if (titleText != null)
        {
            titleText.text = newTitle;
            Debug.Log("游戏标题配置器: 游戏标题已更新为: " + newTitle);
        }
        else
        {
            Debug.LogError("游戏标题配置器: 无法设置标题，Text组件未找到!");
        }
    }
}