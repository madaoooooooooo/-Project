using UnityEngine;
using UnityEngine.UI;

public class 摄像机画布适配器 : MonoBehaviour
{
    void Start()
    {
        Camera mainCamera = Camera.main;
        if (mainCamera == null)
        {
            Debug.LogError("场景中没有找到主摄像机！请确保主摄像机已标记为 'MainCamera' Tag.");
            return;
        }

        GameObject welcomeCanvasObject = GameObject.Find("欢迎界面画布");
        if (welcomeCanvasObject == null)
        {
            Debug.LogError("场景中没有找到 '欢迎界面画布' 对象！");
            return;
        }

        Canvas welcomeCanvas = welcomeCanvasObject.GetComponent<Canvas>();
        if (welcomeCanvas == null)
        {
            Debug.LogError("'欢迎界面画布' 上没有 Canvas 组件！");
            return;
        }

        // 设置画布渲染模式为屏幕空间 - 摄像机
        welcomeCanvas.renderMode = RenderMode.ScreenSpaceCamera;
        welcomeCanvas.worldCamera = mainCamera;

        // 调整主摄像机设置
        mainCamera.clearFlags = CameraClearFlags.SolidColor;
        mainCamera.backgroundColor = Color.black;
        mainCamera.nearClipPlane = 0.1f;
        mainCamera.farClipPlane = 1000f;

        Debug.Log("主摄像机和欢迎界面画布设置已调整。");
    }
} 