using UnityEngine;
using UnityEngine.UI;

public class 按钮背景设置器 : MonoBehaviour
{
    void Start()
    {
        Image buttonImage = GetComponent<Image>();
        if (buttonImage != null)
        {
            buttonImage.color = new Color(1, 1, 1, 0); // Completely transparent white
            buttonImage.sprite = null; // Ensure no default sprite is rendered
            Debug.Log("Button background set to transparent.");
        }
    }
}